package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.GoldRating
import com.example.ui.theme.LahzathaGreen
import com.example.ui.theme.LahzathaGreenDark
import com.example.ui.theme.RedEmergency

@Composable
fun RatingDialog(
    captainName: String,
    totalFare: Double,
    onDismiss: () -> Unit,
    onSubmit: (Int, Double) -> Unit
) {
    var selectedStars by remember { mutableIntStateOf(5) }
    var selectedTip by remember { mutableDoubleStateOf(10.0) }
    val compliments = listOf("قيادة آمنة", "سيارة نظيفة", "كابتن محترم", "طريق مختصر", "تكييف ممتاز")
    var selectedCompliments by remember { mutableStateOf(setOf("قيادة آمنة", "كابتن محترم")) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .clip(CircleShape)
                        .background(LahzathaGreen.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "تم الوصول",
                        tint = LahzathaGreenDark,
                        modifier = Modifier.size(36.dp)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "وصلت بالسلامة!",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "أجرة الرحلة: $totalFare ج.م",
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "كيف كانت تجربتك مع $captainName؟",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(12.dp))

                // 5 Star rating selector
                Row(
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    for (i in 1..5) {
                        IconButton(
                            onClick = { selectedStars = i },
                            modifier = Modifier.size(44.dp)
                        ) {
                            Icon(
                                imageVector = if (i <= selectedStars) Icons.Default.Star else Icons.Default.StarBorder,
                                contentDescription = "$i نجوم",
                                tint = GoldRating,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Compliments chips
                Text(
                    text = "ما الذي أعجبك؟",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    for (comp in compliments.take(3)) {
                        val isSelected = selectedCompliments.contains(comp)
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (isSelected) LahzathaGreen.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier
                                .padding(horizontal = 4.dp)
                                .clickable {
                                    selectedCompliments = if (isSelected) {
                                        selectedCompliments - comp
                                    } else {
                                        selectedCompliments + comp
                                    }
                                }
                        ) {
                            Text(
                                text = comp,
                                fontSize = 11.sp,
                                color = if (isSelected) LahzathaGreenDark else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Tipping row
                Text(
                    text = "إضافة إكرامية للكابتن (اختياري)",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val tipOptions = listOf(0.0, 5.0, 10.0, 20.0)
                    for (tip in tipOptions) {
                        val isSelected = selectedTip == tip
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSelected) LahzathaGreen else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.clickable { selectedTip = tip }
                        ) {
                            Text(
                                text = if (tip == 0.0) "بدون" else "+${tip.toInt()} ج.م",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmit(selectedStars, selectedTip) },
                colors = ButtonDefaults.buttonColors(containerColor = LahzathaGreenDark),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("submit_rating_button")
            ) {
                Text("إرسال التقييم وإنهاء", fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun PromoCodeDialog(
    currentCode: String,
    error: String?,
    onDismiss: () -> Unit,
    onApply: (String) -> Unit
) {
    var codeInput by remember { mutableStateOf(currentCode) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.LocalOffer,
                    contentDescription = null,
                    tint = LahzathaGreenDark
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("إضافة كود خصم (بروموكود)")
            }
        },
        text = {
            Column {
                Text(
                    text = "أدخل كود الخصم للاستفادة من خصومات لحظتها الحصرية (مثال: LAHZA20 أو WELCOME50):",
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = codeInput,
                    onValueChange = { codeInput = it },
                    placeholder = { Text("LAHZA20") },
                    isError = error != null,
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("promo_input_field")
                )
                if (error != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = error,
                        color = MaterialTheme.colorScheme.error,
                        fontSize = 12.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onApply(codeInput) },
                colors = ButtonDefaults.buttonColors(containerColor = LahzathaGreenDark),
                modifier = Modifier.testTag("apply_promo_btn")
            ) {
                Text("تطبيق الخصم")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
fun TopUpDialog(
    onDismiss: () -> Unit,
    onConfirm: (Double) -> Unit
) {
    var customAmount by remember { mutableStateOf("100") }
    val quickAmounts = listOf(50.0, 100.0, 200.0, 500.0)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AccountBalanceWallet,
                    contentDescription = null,
                    tint = LahzathaGreenDark
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("شحن محفظة لحظتها Pay")
            }
        },
        text = {
            Column {
                Text(
                    text = "اختر المبلغ أو أدخل قيمة الشحن المطلوبة بالجنيه المصري:",
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    for (amt in quickAmounts) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (customAmount == amt.toInt().toString()) LahzathaGreen else MaterialTheme.colorScheme.surfaceVariant,
                            modifier = Modifier.clickable { customAmount = amt.toInt().toString() }
                        ) {
                            Text(
                                text = "${amt.toInt()} ج.م",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (customAmount == amt.toInt().toString()) Color.White else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = customAmount,
                    onValueChange = { customAmount = it },
                    label = { Text("المبلغ (ج.م)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("topup_amount_input")
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CreditCard,
                        contentDescription = null,
                        tint = LahzathaGreenDark,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "الدفع آمن ومحمي عبر Visa / Mastercard / فودافون كاش",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parsed = customAmount.toDoubleOrNull() ?: 100.0
                    onConfirm(parsed)
                },
                colors = ButtonDefaults.buttonColors(containerColor = LahzathaGreenDark),
                modifier = Modifier.testTag("confirm_topup_btn")
            ) {
                Text("تأكيد الشحن الفوري")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

@Composable
fun SosEmergencyDialog(
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = RedEmergency,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "مركز طوارئ لحظتها (SOS)",
                    color = RedEmergency,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column {
                Text(
                    text = "سلامتك هي أولويتنا القصوى! يمكنك اتخاذ الإجراءات السريعة التالية بنقرة واحدة:",
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = RedEmergency.copy(alpha = 0.1f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "🚨 الاتصال المباشر بشرطة النجدة (122)",
                            fontWeight = FontWeight.Bold,
                            color = RedEmergency,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "مشاركة إحداثيات موقعك الحالي مع غرفة العمليات.",
                            fontSize = 11.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "📲 مشاركة مسار الرحلة المباشر مع العائلة",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "إرسال رابط تتبع لحظي عبر واتساب أو رسالة نصية.",
                            fontSize = 11.sp
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = RedEmergency)
            ) {
                Text("إغلاق التنبيه")
            }
        }
    )
}

@Composable
fun AdminLoginDialog(
    initialEmail: String = "mahmoudomran324@gmail.com",
    errorMessage: String?,
    onDismiss: () -> Unit,
    onLogin: (email: String, password: String) -> Unit
) {
    var email by remember { mutableStateOf(initialEmail) }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(LahzathaGreen.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AdminPanelSettings,
                        contentDescription = null,
                        tint = LahzathaGreenDark,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "تسجيل دخول إدارة التطبيق 🛡️",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = LahzathaGreenDark
                    )
                    Text(
                        text = "لوحة تحكم محمية وخاصة بالمدير فقط",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        text = {
            Column {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = LahzathaGreen.copy(alpha = 0.08f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "🔒 تنبيه أمني مشدد:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = LahzathaGreenDark
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "لا يمكن لأي مستخدم أو كابتن الدخول للوحة التحكم بدون تسجيل الدخول بحساب المدير المعتمد رسمياً.",
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "الحسابات المصرح لها كأدمن:",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))

                // Quick selector chips for the user's admin emails
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (email == "mahmoudomran324@gmail.com") LahzathaGreenDark else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { email = "mahmoudomran324@gmail.com" }
                    ) {
                        Text(
                            text = "mahmoudomran324@...",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (email == "mahmoudomran324@gmail.com") Color.White else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
                            textAlign = TextAlign.Center
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (email == "yehyaomran99@gmail.com") LahzathaGreenDark else MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { email = "yehyaomran99@gmail.com" }
                    ) {
                        Text(
                            text = "yehyaomran99@...",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (email == "yehyaomran99@gmail.com") Color.White else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(vertical = 6.dp, horizontal = 4.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("البريد الإلكتروني للأدمن") },
                    leadingIcon = {
                        Icon(Icons.Default.Email, contentDescription = null, tint = LahzathaGreenDark)
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_email_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("كلمة المرور السرية") },
                    leadingIcon = {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = LahzathaGreenDark)
                    },
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = if (passwordVisible) "إخفاء" else "إظهار",
                                tint = Color.Gray
                            )
                        }
                    },
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_password_input")
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = errorMessage,
                        color = RedEmergency,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "💡 كلمة مرور الأدمن الافتراضية: Admin2026 أو 9924",
                    fontSize = 10.sp,
                    color = Color.Gray
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onLogin(email, password) },
                colors = ButtonDefaults.buttonColors(containerColor = LahzathaGreenDark),
                modifier = Modifier.testTag("admin_login_submit_btn")
            ) {
                Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("دخول كأدمن معتمد", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}

