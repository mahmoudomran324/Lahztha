package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Careem & Lahzatha Signature Brand Colors
val LahzathaGreen = Color(0xFF00C853)
val LahzathaGreenDark = Color(0xFF009624)
val LahzathaGreenLight = Color(0xFF69F0AE)
val LahzathaGreenAccent = Color(0xFF00E676)
val LahzathaEmeraldDeep = Color(0xFF0A2E1D)

// Neutral & Backgrounds
val DarkBackground = Color(0xFF0D1410)
val DarkSurface = Color(0xFF15221B)
val DarkCard = Color(0xFF1E3026)
val LightBackground = Color(0xFFF7FAF8)
val LightSurface = Color(0xFFFFFFFF)
val LightCard = Color(0xFFF0F5F2)

// Text Colors
val TextPrimaryDark = Color(0xFFF1F5F3)
val TextSecondaryDark = Color(0xFFA0B2A8)
val TextPrimaryLight = Color(0xFF121B16)
val TextSecondaryLight = Color(0xFF5E7166)

// Functional & Accents
val GoldRating = Color(0xFFFFB300)
val RedEmergency = Color(0xFFFF3D57)
val BlueInfo = Color(0xFF2979FF)
val OrangeWarning = Color(0xFFFF9100)
val RouteGreen = Color(0xFF00E676)
val RouteTrafficRed = Color(0xFFFF5252)
val RouteTrafficOrange = Color(0xFFFFAB40)
