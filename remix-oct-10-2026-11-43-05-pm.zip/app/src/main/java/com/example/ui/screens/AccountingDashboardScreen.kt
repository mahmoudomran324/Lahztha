package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ElectricCar
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PriceChange
import androidx.compose.material.icons.filled.PriceCheck
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Sell
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ApplicationStatus
import com.example.data.model.CategoryPricing
import com.example.data.model.CommissionDebtItem
import com.example.data.model.DriverApplication
import com.example.data.model.GoldReward
import com.example.data.model.PromoOffer
import com.example.data.model.RideCategory
import com.example.data.model.VehicleCategory
import com.example.ui.theme.GoldRating
import com.example.ui.theme.LahzathaEmeraldDeep
import com.example.ui.theme.LahzathaGreen
import com.example.ui.theme.LahzathaGreenAccent
import com.example.ui.theme.LahzathaGreenDark
import com.example.ui.theme.RedEmergency
import com.example.ui.viewmodel.UiState

enum class AdminDashboardTab(val titleAr: String, val icon: ImageVector) {
    VEHICLES("المركبات والأسعار", Icons.Default.DirectionsCar),
    DOCUMENTS("توثيق أوراق الكباتن", Icons.Default.Assignment),
    GOLD_REWARDS("مكافآت الذهب", Icons.Default.Stars),
    PROMOS("العروض والخصم", Icons.Default.LocalOffer),
    COMMISSIONS("الأرباح والعمولات", Icons.Default.AccountBalance)
}

@Composable
fun AccountingDashboardScreen(
    state: UiState,
    onDeductCommission: (CommissionDebtItem) -> Unit,
    onSettleAllCaptainDebts: () -> Unit,
    onUpdateCommissionRate: (Double) -> Unit,
    onUpdateMaxDebtLimit: (Double) -> Unit,
    onUpdateCategoryPricing: (RideCategory, Double, Double) -> Unit = { _, _, _ -> },
    onResetPricing: () -> Unit = {},
    onAddNewPromoOffer: (String, String, Int, String) -> Unit = { _, _, _, _ -> },
    onDeletePromoOffer: (String) -> Unit = {},
    onTogglePromoOffer: (String) -> Unit = {},
    onAddNewVehicleCategory: (String, String, String, Double, Double, Int, Int) -> Unit = { _, _, _, _, _, _, _ -> },
    onDeleteVehicleCategory: (String) -> Unit = {},
    onToggleVehicleCategory: (String) -> Unit = {},
    onUpdateVehicleCategoryDetails: (String, String, Double, Double, Int, Int) -> Unit = { _, _, _, _, _, _ -> },
    onResetVehicleCategories: () -> Unit = {},
    onSendGoldReward: (String, String, Double, String) -> Unit = { _, _, _, _ -> },
    onApproveDriverApplication: (String) -> Unit = {},
    onRejectDriverApplication: (String, String) -> Unit = { _, _ -> },
    onLogoutAdmin: () -> Unit = {}
) {
    var selectedDashboardTab by remember { mutableStateOf(AdminDashboardTab.VEHICLES) }
    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, UNPAID, PAID
    var showSettingsDialog by remember { mutableStateOf(false) }
    var itemToDeduct by remember { mutableStateOf<CommissionDebtItem?>(null) }

    // Dialog state for adding a new vehicle category (Scooter, TukTuk, Car, etc.)
    var showAddVehicleDialog by remember { mutableStateOf(false) }

    // Dialog state for editing a vehicle category
    var vehicleToEdit by remember { mutableStateOf<VehicleCategory?>(null) }

    // Dialog state for deleting a vehicle category
    var vehicleToDelete by remember { mutableStateOf<VehicleCategory?>(null) }

    // Dialog state for adding a new promo offer
    var showAddPromoDialog by remember { mutableStateOf(false) }

    // Dialog state for deleting a promo offer
    var offerToDelete by remember { mutableStateOf<PromoOffer?>(null) }

    // Dialog state for sending Gold Reward
    var showSendGoldDialog by remember { mutableStateOf(false) }

    // Dialog state for rejecting a driver application
    var applicationToReject by remember { mutableStateOf<DriverApplication?>(null) }

    val filteredDebts = remember(state.commissionDebtsList, selectedFilter) {
        when (selectedFilter) {
            "UNPAID" -> state.commissionDebtsList.filter { !it.isSettled }
            "PAID" -> state.commissionDebtsList.filter { it.isSettled }
            else -> state.commissionDebtsList
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp)
            .testTag("admin_dashboard_screen")
    ) {
        item {
            Spacer(modifier = Modifier.height(16.dp))

            // Main Emerald Header Card
            Card(
                shape = RoundedCornerShape(22.dp),
                modifier = Modifier.fillMaxWidth(),
                elevation = CardDefaults.cardElevation(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(LahzathaEmeraldDeep, Color(0xFF0D3D25), Color(0xFF135334))
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(LahzathaGreenAccent.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AccountBalance,
                                        contentDescription = null,
                                        tint = LahzathaGreenAccent,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "لوحة تحكم إدارة التطبيق",
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White,
                                        fontSize = 18.sp
                                    )
                                    Text(
                                        text = "توثيق المستندات • مكافآت الذهب • وسائل التنقل والأسعار",
                                        color = Color.White.copy(alpha = 0.85f),
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color.White.copy(alpha = 0.15f)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.VerifiedUser,
                                            contentDescription = null,
                                            tint = LahzathaGreenAccent,
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = (state.authenticatedAdminEmail ?: "mahmoudomran324@gmail.com").take(18) + if ((state.authenticatedAdminEmail ?: "").length > 18) "..." else "",
                                            color = Color.White,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.width(6.dp))

                                IconButton(
                                    onClick = onLogoutAdmin,
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.15f))
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Lock,
                                        contentDescription = "قفل وخروج الأدمن",
                                        tint = Color(0xFFFF8A80),
                                        modifier = Modifier.size(17.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(4.dp))

                                IconButton(
                                    onClick = { showSettingsDialog = true },
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(CircleShape)
                                        .background(Color.White.copy(alpha = 0.15f))
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PriceCheck,
                                        contentDescription = "إعدادات العمولة",
                                        tint = LahzathaGreenAccent,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Stats Summary Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Pending Applications Count
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.1f)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Badge,
                                            contentDescription = null,
                                            tint = LahzathaGreenAccent,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "طلبات التوثيق",
                                            color = Color.White.copy(alpha = 0.85f),
                                            fontSize = 11.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "${state.driverApplicationsList.count { it.status == ApplicationStatus.PENDING }} قيد الفحص",
                                        color = LahzathaGreenAccent,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // Gold Incentives
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.1f)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Stars,
                                            contentDescription = null,
                                            tint = GoldRating,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "مكافآت الذهب الموزعة",
                                            color = Color.White.copy(alpha = 0.85f),
                                            fontSize = 11.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "${state.goldRewardsHistory.sumOf { it.goldGrams }} جرام عيار 21",
                                        color = GoldRating,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Scrollable SubTabs Bar (المركبات والأسعار | توثيق أوراق الكباتن | مكافآت الذهب | العروض والخصم | الأرباح والعمولات)
            ScrollableTabRow(
                selectedTabIndex = selectedDashboardTab.ordinal,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = LahzathaGreenDark,
                edgePadding = 8.dp,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedDashboardTab.ordinal]),
                        color = LahzathaGreenDark,
                        height = 3.dp
                    )
                },
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(14.dp))
            ) {
                AdminDashboardTab.values().forEach { tab ->
                    val isSelected = selectedDashboardTab == tab
                    Tab(
                        selected = isSelected,
                        onClick = { selectedDashboardTab = tab },
                        text = {
                            Text(
                                text = tab.titleAr,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                color = if (isSelected) LahzathaGreenDark else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.titleAr,
                                modifier = Modifier.size(18.dp),
                                tint = if (isSelected) LahzathaGreenDark else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // ==============================================================
        // SUBTAB 1: وسـائـل الـتـنـقـل والأسـعـار (VEHICLES & PRICING)
        // ==============================================================
        if (selectedDashboardTab == AdminDashboardTab.VEHICLES) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "وسائل التنقل المقبولة وتسعيرتها",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "إضافة سكوتر، توكتوك أو فئات جديدة، حذفها، أو تعديل أسعارها",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = { showAddVehicleDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = LahzathaGreenDark),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.testTag("add_vehicle_category_btn")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("إضافة وسيلة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = onResetVehicleCategories,
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(14.dp))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
            }

            items(state.vehicleCategories) { vCat ->
                val sample10KmCost = Math.round(vCat.baseFare + (10.0 * vCat.perKmRate))

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (vCat.isEnabled) LahzathaGreen.copy(alpha = 0.12f)
                                            else Color.Gray.copy(alpha = 0.12f)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = when (vCat.vehicleType.uppercase()) {
                                            "SCOOTER", "MOTORCYCLE" -> Icons.Default.TwoWheeler
                                            "ECO" -> Icons.Default.ElectricCar
                                            "DELIVERY" -> Icons.Default.LocalShipping
                                            else -> Icons.Default.DirectionsCar
                                        },
                                        contentDescription = null,
                                        tint = if (vCat.isEnabled) LahzathaGreenDark else Color.Gray,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = vCat.titleAr,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = when (vCat.vehicleType.uppercase()) {
                                                "SCOOTER" -> GoldRating.copy(alpha = 0.2f)
                                                "DELIVERY" -> Color(0xFFE0E7FF)
                                                else -> LahzathaGreen.copy(alpha = 0.15f)
                                            }
                                        ) {
                                            Text(
                                                text = when (vCat.vehicleType.uppercase()) {
                                                    "SCOOTER" -> "سكوتر فردي"
                                                    "MOTORCYCLE" -> "موتوسيكل"
                                                    "DELIVERY" -> "توصيل طرود"
                                                    "VAN" -> "فان عائلي"
                                                    else -> "سيارة ملاكي"
                                                },
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = when (vCat.vehicleType.uppercase()) {
                                                    "SCOOTER" -> Color(0xFF9E6C00)
                                                    "DELIVERY" -> Color(0xFF3730A3)
                                                    else -> LahzathaGreenDark
                                                },
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }

                                    Text(
                                        text = "${vCat.subtitleAr} • ${vCat.seats} مقعد • ${vCat.etaMinutes} دقيقة وصول",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Toggle active status
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (vCat.isEnabled) LahzathaGreen.copy(alpha = 0.15f) else Color.Gray.copy(alpha = 0.15f),
                                    modifier = Modifier
                                        .clickable { onToggleVehicleCategory(vCat.id) }
                                        .padding(end = 6.dp)
                                ) {
                                    Text(
                                        text = if (vCat.isEnabled) "متاحة للركاب" else "معطلة",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (vCat.isEnabled) LahzathaGreenDark else Color.Gray,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp)
                                    )
                                }

                                // Edit button
                                IconButton(
                                    onClick = { vehicleToEdit = vCat },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = LahzathaGreenDark, modifier = Modifier.size(18.dp))
                                }

                                // Delete button
                                IconButton(
                                    onClick = { vehicleToDelete = vCat },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف", tint = RedEmergency, modifier = Modifier.size(18.dp))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Divider(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(10.dp))

                        // Current pricing pills
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = LahzathaGreen.copy(alpha = 0.08f),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("فتح العداد", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(
                                        text = "${vCat.baseFare.toInt()} ج.م",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = LahzathaGreenDark
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = LahzathaGreen.copy(alpha = 0.08f),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("سعر الكيلو", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(
                                        text = "${vCat.perKmRate} ج.م",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = LahzathaGreenDark
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = GoldRating.copy(alpha = 0.12f),
                                modifier = Modifier.weight(1.2f)
                            ) {
                                Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("أجرة 10 كم تقريباً", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(
                                        text = "$sample10KmCost ج.م",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = Color(0xFFB78103)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==============================================================
        // SUBTAB 2: تـوثـيـق أوراق الـكـبـاتـن (DRIVER DOCUMENTS)
        // ==============================================================
        else if (selectedDashboardTab == AdminDashboardTab.DOCUMENTS) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Verified, contentDescription = null, tint = LahzathaGreenDark, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("شروط ومستندات قبول السائقين الرسمية:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "لضمان أمان وسلامة الركاب، يشترط رفع 4 مستندات إلزامية لكل كابتن:\n" +
                                    "1. صورة وجه رخصة القيادة السارية\n" +
                                    "2. صورة ظهر رخصة القيادة\n" +
                                    "3. صورة رخصة تسيير المركبة (السيارة/السكوتر)\n" +
                                    "4. صورة بطاقة الرقم القومي (14 رقماً)",
                            fontSize = 11.sp,
                            lineHeight = 17.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "طلبات تسجيل الكباتن وفحص المستندات:",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            items(state.driverApplicationsList) { app ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape)
                                        .background(
                                            when (app.status) {
                                                ApplicationStatus.APPROVED -> LahzathaGreen.copy(alpha = 0.15f)
                                                ApplicationStatus.PENDING -> GoldRating.copy(alpha = 0.2f)
                                                ApplicationStatus.REJECTED -> RedEmergency.copy(alpha = 0.15f)
                                            }
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = when (app.status) {
                                            ApplicationStatus.APPROVED -> Icons.Default.CheckCircle
                                            ApplicationStatus.PENDING -> Icons.Default.Badge
                                            ApplicationStatus.REJECTED -> Icons.Default.Cancel
                                        },
                                        contentDescription = null,
                                        tint = when (app.status) {
                                            ApplicationStatus.APPROVED -> LahzathaGreenDark
                                            ApplicationStatus.PENDING -> Color(0xFFB78103)
                                            ApplicationStatus.REJECTED -> RedEmergency
                                        },
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(text = app.fullName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(
                                        text = "الرقم القومي: ${app.nationalId} • ${app.phone}",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "${app.vehicleType}: ${app.carModel} (${app.plateNumber})",
                                        fontSize = 11.sp,
                                        color = LahzathaGreenDark,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = when (app.status) {
                                    ApplicationStatus.APPROVED -> LahzathaGreenDark
                                    ApplicationStatus.PENDING -> GoldRating
                                    ApplicationStatus.REJECTED -> RedEmergency
                                }
                            ) {
                                Text(
                                    text = app.status.titleAr,
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Divider(color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(10.dp))

                        // Visual Document Badges Row
                        Text(text = "حالة رفع المستندات والأوراق الرسمية:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (app.licenseFrontUploaded) LahzathaGreen.copy(alpha = 0.12f) else RedEmergency.copy(alpha = 0.12f),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("وجه الرخصة", fontSize = 9.sp)
                                    Text(if (app.licenseFrontUploaded) "مرفوع ✓" else "ناقص ✗", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (app.licenseFrontUploaded) LahzathaGreenDark else RedEmergency)
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (app.licenseBackUploaded) LahzathaGreen.copy(alpha = 0.12f) else RedEmergency.copy(alpha = 0.12f),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("ظهر الرخصة", fontSize = 9.sp)
                                    Text(if (app.licenseBackUploaded) "مرفوع ✓" else "ناقص ✗", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (app.licenseBackUploaded) LahzathaGreenDark else RedEmergency)
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (app.carLicenseUploaded) LahzathaGreen.copy(alpha = 0.12f) else RedEmergency.copy(alpha = 0.12f),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("رخصة المركبة", fontSize = 9.sp)
                                    Text(if (app.carLicenseUploaded) "مرفوع ✓" else "ناقص ✗", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (app.carLicenseUploaded) LahzathaGreenDark else RedEmergency)
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (app.nationalIdUploaded) LahzathaGreen.copy(alpha = 0.12f) else RedEmergency.copy(alpha = 0.12f),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("الرقم القومي", fontSize = 9.sp)
                                    Text(if (app.nationalIdUploaded) "مرفوع ✓" else "ناقص ✗", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (app.nationalIdUploaded) LahzathaGreenDark else RedEmergency)
                                }
                            }
                        }

                        if (app.rejectionReason != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "سبب الرفض: ${app.rejectionReason}",
                                fontSize = 11.sp,
                                color = RedEmergency,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        if (app.status == ApplicationStatus.PENDING) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = { onApproveDriverApplication(app.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = LahzathaGreenDark),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("قبول واعتماد الكابتن", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = { applicationToReject = app },
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Cancel, contentDescription = null, tint = RedEmergency, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("رفض الطلب", fontSize = 11.sp, color = RedEmergency)
                                }
                            }
                        }
                    }
                }
            }
        }

        // ==============================================================
        // SUBTAB 3: مـكـافـآت الـذهـب (GOLD REWARDS)
        // ==============================================================
        else if (selectedDashboardTab == AdminDashboardTab.GOLD_REWARDS) {
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = GoldRating.copy(alpha = 0.15f)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldRating.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(GoldRating.copy(alpha = 0.25f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Stars, contentDescription = null, tint = Color(0xFFB78103), modifier = Modifier.size(28.dp))
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("نظام حوافز سبائك الذهب 🏅", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFF6B4800))
                                    Text("إرسال مكافآت وجرامات ذهب عيار 21 مباشرة للكباتن المتميزين", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            Button(
                                onClick = { showSendGoldDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB78103)),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("send_gold_btn")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("إرسال ذهب", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Text("سجل مكافآت وحوافز الذهب المرسلة للكباتن:", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(modifier = Modifier.height(8.dp))
            }

            items(state.goldRewardsHistory) { reward ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(GoldRating.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Stars, contentDescription = null, tint = Color(0xFFB78103), modifier = Modifier.size(24.dp))
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = reward.captainName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(shape = RoundedCornerShape(6.dp), color = GoldRating.copy(alpha = 0.25f)) {
                                        Text(
                                            text = "${reward.goldGrams} جرام ذهب",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = Color(0xFF7A5400),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Text(text = reward.reason, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(text = reward.date, fontSize = 10.sp, color = Color.Gray)
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "القيمة المعاصرة:",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "${reward.equivalentEgp.toInt()} ج.م",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = LahzathaGreenDark
                            )
                        }
                    }
                }
            }
        }

        // ==============================================================
        // SUBTAB 4: إدارة الـعـروض وأكـواد الـخـصـم (PROMOS)
        // ==============================================================
        else if (selectedDashboardTab == AdminDashboardTab.PROMOS) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "أكواد الخصم والعروض الترويجية",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = "إضافة كود جديد، تفعيل/إيقاف العرض أو حذفه",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Button(
                        onClick = { showAddPromoDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = LahzathaGreenDark),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("add_new_promo_btn")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("إضافة كود جديد", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
            }

            items(state.promoOffersList) { offer ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (offer.isActive) LahzathaGreen.copy(alpha = 0.15f)
                                        else Color.Gray.copy(alpha = 0.15f)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Sell,
                                    contentDescription = null,
                                    tint = if (offer.isActive) LahzathaGreenDark else Color.Gray,
                                    modifier = Modifier.size(22.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = if (offer.isActive) LahzathaGreenDark else Color.Gray
                                    ) {
                                        Text(
                                            text = offer.code,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = GoldRating.copy(alpha = 0.2f)
                                    ) {
                                        Text(
                                            text = "خصم ${offer.discountPercent}%",
                                            color = Color(0xFF9E6C00),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = offer.titleAr,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = "${offer.expiryNote} • استُخدم ${offer.usageCount} مرة",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Toggle Active Button
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (offer.isActive) LahzathaGreen.copy(alpha = 0.15f) else Color.Gray.copy(alpha = 0.15f),
                                modifier = Modifier
                                    .clickable { onTogglePromoOffer(offer.id) }
                                    .padding(end = 6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (offer.isActive) Icons.Default.CheckCircle else Icons.Default.Cancel,
                                        contentDescription = null,
                                        tint = if (offer.isActive) LahzathaGreenDark else Color.Gray,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (offer.isActive) "نشط" else "معطل",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (offer.isActive) LahzathaGreenDark else Color.Gray
                                    )
                                }
                            }

                            // Delete Button
                            IconButton(
                                onClick = { offerToDelete = offer },
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(RedEmergency.copy(alpha = 0.1f))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "حذف العرض",
                                    tint = RedEmergency,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // ==============================================================
        // SUBTAB 5: الأربـاح والـعـمـولات (COMMISSIONS)
        // ==============================================================
        else {
            item {
                // Enforcement & Collection Mechanics Banner
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = null,
                                tint = LahzathaGreenDark,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "آلية التطبيق لضمان استرداد وسحب الأرباح من الكابتن:",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "1. الخصم المباشر: في رحلات البطاقة والمحفظة، يتم استقطاع عمولة المنصة ${(state.appCommissionRate * 100).toInt()}% فوراً وإيداع الصافي فقط في حساب السائق.\n" +
                                    "2. رحلات الكاش: يتم احتساب العمولة كمديونية تلقائية على الكابتن.\n" +
                                    "3. حظر الرحلات النقدية: إذا بلغت مديونية السائق ${state.captainProfile.maxDebtLimit.toInt()} ج.م يُحظر فوراً من استقبال طلبات الكاش حتى يسدد عمولة المنصة.",
                            fontSize = 11.sp,
                            lineHeight = 17.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Current Captain Debt Spotlight Card
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (state.captainProfile.commissionDebt > 0)
                            RedEmergency.copy(alpha = 0.08f) else LahzathaGreen.copy(alpha = 0.08f)
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (state.captainProfile.commissionDebt > 0) RedEmergency.copy(alpha = 0.3f) else LahzathaGreen.copy(alpha = 0.3f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "حساب الكابتن الحالي: ${state.captainProfile.name}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "سيارة ${state.captainProfile.carModel} • ${state.captainProfile.plateNumber}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            // Debt Pill
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (state.captainProfile.commissionDebt > 0) RedEmergency else LahzathaGreenDark
                            ) {
                                Text(
                                    text = "مستحق: ${state.captainProfile.commissionDebt} ج.م",
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = onSettleAllCaptainDebts,
                                colors = ButtonDefaults.buttonColors(containerColor = LahzathaGreenDark),
                                enabled = state.captainProfile.commissionDebt > 0,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("settle_captain_debts_btn")
                            ) {
                                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("سحب وتسوية المديونية بالكامل", fontSize = 12.sp)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Filter Tabs for Ledger
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "سجل عمولات الرحلات النقدية",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(
                            selected = selectedFilter == "ALL",
                            onClick = { selectedFilter = "ALL" },
                            label = { Text("الكل", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = LahzathaGreenDark,
                                selectedLabelColor = Color.White
                            )
                        )
                        FilterChip(
                            selected = selectedFilter == "UNPAID",
                            onClick = { selectedFilter = "UNPAID" },
                            label = { Text("مستحقة", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = RedEmergency,
                                selectedLabelColor = Color.White
                            )
                        )
                        FilterChip(
                            selected = selectedFilter == "PAID",
                            onClick = { selectedFilter = "PAID" },
                            label = { Text("مسددة", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = LahzathaGreenDark,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
            }

            // List of Commission Debt items
            items(filteredDebts) { item ->
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (item.isSettled) LahzathaGreen.copy(alpha = 0.15f)
                                        else RedEmergency.copy(alpha = 0.15f)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (item.isSettled) Icons.Default.CheckCircle else Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = if (item.isSettled) LahzathaGreenDark else RedEmergency,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "رحلة ${item.rideId} • ${item.captainName}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                                Text(
                                    text = "إجمالي الأجرة: ${item.totalFare} ج.م • ${item.date}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "عمولة: ${item.commissionAmount} ج.م",
                                fontWeight = FontWeight.Bold,
                                color = if (item.isSettled) LahzathaGreenDark else RedEmergency,
                                fontSize = 13.sp
                            )
                            if (!item.isSettled) {
                                Button(
                                    onClick = { itemToDeduct = item },
                                    colors = ButtonDefaults.buttonColors(containerColor = RedEmergency),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .height(28.dp)
                                        .testTag("deduct_commission_${item.id}")
                                ) {
                                    Text("سحب", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            } else {
                                Text(
                                    text = "مسددة",
                                    color = LahzathaGreenDark,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(30.dp))
        }
    }

    // ==========================================
    // DIALOGS
    // ==========================================

    // 1. Send Gold Reward Dialog
    if (showSendGoldDialog) {
        var captainNameInput by remember { mutableStateOf(state.captainProfile.name) }
        var goldGramsInput by remember { mutableStateOf("2.5") }
        var reasonInput by remember { mutableStateOf("مكافأة الكابتن المثالي وإنجاز تارجت الرحلات") }

        AlertDialog(
            onDismissRequest = { showSendGoldDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Stars, contentDescription = null, tint = Color(0xFFB78103))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("إرسال مكافأة ذهب للكابتن 🏅")
                }
            },
            text = {
                Column {
                    Text(
                        text = "اختر كمية الذهب (جرامات عيار 21) والمكافأة التي ترغب في إرسالها لحساب الكابتن:",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("اسم الكابتن المستلم:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = captainNameInput,
                        onValueChange = { captainNameInput = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("كمية الذهب (جرام):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val gramOptions = listOf("1.0", "2.5", "5.0", "10.0")
                        gramOptions.forEach { g ->
                            FilterChip(
                                selected = goldGramsInput == g,
                                onClick = { goldGramsInput = g },
                                label = { Text("$g ج", fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFFB78103),
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = goldGramsInput,
                        onValueChange = { goldGramsInput = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("سبب ومنح المكافأة:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = reasonInput,
                        onValueChange = { reasonInput = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val grams = goldGramsInput.toDoubleOrNull() ?: 1.0
                        onSendGoldReward("cpt_101", captainNameInput, grams, reasonInput)
                        showSendGoldDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB78103))
                ) {
                    Text("إرسال الذهب فوراً")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showSendGoldDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // 2. Reject Driver Application Dialog
    applicationToReject?.let { app ->
        var rejectReasonInput by remember { mutableStateOf("صورة رخصة القيادة غير واضحة المعالم، يرجى إعادة التصوير والرفع") }

        AlertDialog(
            onDismissRequest = { applicationToReject = null },
            title = { Text("رفض طلب الكابتن مع توضيح السبب") },
            text = {
                Column {
                    Text("طلب الكابتن: ${app.fullName}", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("اكتب ملاحظات الرفض لتصل للكابتن لإعادة رفع المستندات المطلوبة:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = rejectReasonInput,
                        onValueChange = { rejectReasonInput = it },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRejectDriverApplication(app.id, rejectReasonInput)
                        applicationToReject = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedEmergency)
                ) {
                    Text("تأكيد الرفض")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { applicationToReject = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // 3. Add New Vehicle Category Dialog (Scooter, TukTuk, Car, Van, Delivery)
    if (showAddVehicleDialog) {
        var titleInput by remember { mutableStateOf("") }
        var subtitleInput by remember { mutableStateOf("") }
        var vehicleTypeInput by remember { mutableStateOf("SCOOTER") }
        var baseFareInput by remember { mutableStateOf("12") }
        var perKmInput by remember { mutableStateOf("3.0") }
        var seatsInput by remember { mutableStateOf("1") }
        var etaInput by remember { mutableStateOf("2") }

        AlertDialog(
            onDismissRequest = { showAddVehicleDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = LahzathaGreenDark)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("إضافة وسيلة تنقل جديدة")
                }
            },
            text = {
                Column {
                    Text(
                        text = "حدد نوع وسيلة التنقل والأسعار المقبولة (مثال: سكوتر، توكتوك):",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Text("اسم الفئة (مثال: لحظتها سكوتر):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = titleInput,
                        onValueChange = { titleInput = it },
                        placeholder = { Text("لحظتها سكوتر السريع") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("new_vehicle_title_input")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("نوع المركبة والأيقونة:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val types = listOf("SCOOTER" to "سكوتر", "CAR" to "سيارة", "DELIVERY" to "توصيل", "VAN" to "فان")
                        types.forEach { (typeKey, typeLabel) ->
                            FilterChip(
                                selected = vehicleTypeInput == typeKey,
                                onClick = {
                                    vehicleTypeInput = typeKey
                                    if (typeKey == "SCOOTER") {
                                        seatsInput = "1"
                                        baseFareInput = "10"
                                        perKmInput = "2.8"
                                    }
                                },
                                label = { Text(typeLabel, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = LahzathaGreenDark,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("فتح العداد (ج.م):", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            OutlinedTextField(
                                value = baseFareInput,
                                onValueChange = { baseFareInput = it },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("سعر الكيلو (ج.م):", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            OutlinedTextField(
                                value = perKmInput,
                                onValueChange = { perKmInput = it },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("المقاعد:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            OutlinedTextField(
                                value = seatsInput,
                                onValueChange = { seatsInput = it },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("وقت الوصول (د):", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            OutlinedTextField(
                                value = etaInput,
                                onValueChange = { etaInput = it },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val base = baseFareInput.toDoubleOrNull() ?: 12.0
                        val perKm = perKmInput.toDoubleOrNull() ?: 3.0
                        val seats = seatsInput.toIntOrNull() ?: 1
                        val eta = etaInput.toIntOrNull() ?: 3
                        if (titleInput.isNotBlank()) {
                            onAddNewVehicleCategory(titleInput, subtitleInput.ifBlank { "تنقل سريع واقتصادي" }, vehicleTypeInput, base, perKm, seats, eta)
                            showAddVehicleDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LahzathaGreenDark),
                    enabled = titleInput.isNotBlank(),
                    modifier = Modifier.testTag("confirm_add_vehicle_btn")
                ) {
                    Text("إضافة وإتاحة للركاب")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showAddVehicleDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // 4. Edit Vehicle Category Dialog
    vehicleToEdit?.let { vCat ->
        var titleInput by remember { mutableStateOf(vCat.titleAr) }
        var baseFareInput by remember { mutableStateOf(vCat.baseFare.toInt().toString()) }
        var perKmInput by remember { mutableStateOf(vCat.perKmRate.toString()) }
        var seatsInput by remember { mutableStateOf(vCat.seats.toString()) }
        var etaInput by remember { mutableStateOf(vCat.etaMinutes.toString()) }

        AlertDialog(
            onDismissRequest = { vehicleToEdit = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Edit, contentDescription = null, tint = LahzathaGreenDark)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("تعديل تسعيرة ${vCat.titleAr}")
                }
            },
            text = {
                Column {
                    Text("اسم الفئة المعروض للركاب:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = titleInput,
                        onValueChange = { titleInput = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("فتح العداد (ج.م):", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            OutlinedTextField(
                                value = baseFareInput,
                                onValueChange = { baseFareInput = it },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("سعر الكيلو (ج.م):", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            OutlinedTextField(
                                value = perKmInput,
                                onValueChange = { perKmInput = it },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("عدد المقاعد:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            OutlinedTextField(
                                value = seatsInput,
                                onValueChange = { seatsInput = it },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text("وقت الوصول (د):", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            OutlinedTextField(
                                value = etaInput,
                                onValueChange = { etaInput = it },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val base = baseFareInput.toDoubleOrNull() ?: vCat.baseFare
                        val perKm = perKmInput.toDoubleOrNull() ?: vCat.perKmRate
                        val seats = seatsInput.toIntOrNull() ?: vCat.seats
                        val eta = etaInput.toIntOrNull() ?: vCat.etaMinutes
                        onUpdateVehicleCategoryDetails(vCat.id, titleInput, base, perKm, seats, eta)
                        vehicleToEdit = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LahzathaGreenDark)
                ) {
                    Text("حفظ التعديلات")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { vehicleToEdit = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // 5. Delete Vehicle Category Confirmation Dialog
    vehicleToDelete?.let { vCat ->
        AlertDialog(
            onDismissRequest = { vehicleToDelete = null },
            title = { Text("تأكيد حذف وسيلة التنقل") },
            text = { Text("هل أنت متأكد من حذف وسيلة التنقل '${vCat.titleAr}' نهائياً من التطبيق؟ لن تظهر للركاب بعد الحذف.") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteVehicleCategory(vCat.id)
                        vehicleToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedEmergency),
                    modifier = Modifier.testTag("confirm_delete_vehicle_btn")
                ) {
                    Text("حذف وسيلة التنقل")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { vehicleToDelete = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // 6. Add Promo Offer Dialog
    if (showAddPromoDialog) {
        var codeInput by remember { mutableStateOf("") }
        var titleInput by remember { mutableStateOf("") }
        var discountInput by remember { mutableStateOf("25") }
        var expiryInput by remember { mutableStateOf("ساري طوال الشهر") }

        AlertDialog(
            onDismissRequest = { showAddPromoDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = LahzathaGreenDark)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("إضافة كود خصم وعرض جديد")
                }
            },
            text = {
                Column {
                    Text(
                        text = "حدد رمز الكود ونسبة الخصم التي ستمنح للركاب:",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("كود الخصم (Promo Code):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = codeInput,
                        onValueChange = { codeInput = it.uppercase() },
                        placeholder = { Text("مثال: SCOOTER20 أو EID30") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("promo_code_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("نسبة الخصم (%):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = discountInput,
                        onValueChange = { discountInput = it },
                        placeholder = { Text("مثال: 25") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("promo_discount_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("عنوان العرض الترويجي:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = titleInput,
                        onValueChange = { titleInput = it },
                        placeholder = { Text("مثال: خصم 20% لرحلات السكوتر") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("promo_title_input")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("ملاحظة الصلاحية:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = expiryInput,
                        onValueChange = { expiryInput = it },
                        placeholder = { Text("مثال: حتى نهاية الأسبوع") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("promo_expiry_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val discount = discountInput.toIntOrNull() ?: 20
                        if (codeInput.isNotBlank()) {
                            onAddNewPromoOffer(codeInput, titleInput, discount, expiryInput)
                            showAddPromoDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LahzathaGreenDark),
                    enabled = codeInput.isNotBlank(),
                    modifier = Modifier.testTag("confirm_add_promo_btn")
                ) {
                    Text("إضافة العرض")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showAddPromoDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // 7. Delete Promo Offer Confirmation Dialog
    offerToDelete?.let { offer ->
        AlertDialog(
            onDismissRequest = { offerToDelete = null },
            title = { Text("تأكيد حذف العرض") },
            text = { Text("هل أنت متأكد من حذف كود الخصم '${offer.code}' (${offer.titleAr}) نهائياً من نظام التطبيق؟") },
            confirmButton = {
                Button(
                    onClick = {
                        onDeletePromoOffer(offer.id)
                        offerToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedEmergency),
                    modifier = Modifier.testTag("confirm_delete_promo_btn")
                ) {
                    Text("حذف العرض")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { offerToDelete = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // 8. Settle Commission Dialog
    itemToDeduct?.let { item ->
        AlertDialog(
            onDismissRequest = { itemToDeduct = null },
            title = { Text("تأكيد سحب عمولة المنصة") },
            text = {
                Text(
                    "هل ترغب في استقطاع وتحصيل مبلغ ${item.commissionAmount} ج.م من حساب الكابتن ${item.captainName} لصالح التطبيق عن الرحلة رقم ${item.rideId}؟"
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeductCommission(item)
                        itemToDeduct = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LahzathaGreenDark)
                ) {
                    Text("تأكيد الاستقطاع")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { itemToDeduct = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // 9. Commission Settings Dialog
    if (showSettingsDialog) {
        var newRate by remember { mutableDoubleStateOf(state.appCommissionRate) }
        var newLimit by remember { mutableDoubleStateOf(state.captainProfile.maxDebtLimit) }

        AlertDialog(
            onDismissRequest = { showSettingsDialog = false },
            title = { Text("إعدادات سياسة عمولات التطبيق") },
            text = {
                Column {
                    Text(
                        text = "تحديد نسبة العمولة المستقطعة من كل رحلة:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        val rates = listOf(0.15, 0.20, 0.25)
                        for (r in rates) {
                            FilterChip(
                                selected = (newRate == r),
                                onClick = { newRate = r },
                                label = { Text("${(r * 100).toInt()}%") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = LahzathaGreenDark,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "الحد الأقصى لمديونية الكابتن قبل حظر رحلات الكاش:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        val limits = listOf(100.0, 150.0, 200.0)
                        for (lim in limits) {
                            FilterChip(
                                selected = (newLimit == lim),
                                onClick = { newLimit = lim },
                                label = { Text("${lim.toInt()} ج.م") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = LahzathaGreenDark,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUpdateCommissionRate(newRate)
                        onUpdateMaxDebtLimit(newLimit)
                        showSettingsDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LahzathaGreenDark)
                ) {
                    Text("حفظ الإعدادات")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showSettingsDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
