package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.AttachMoney
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.RideStatus
import com.example.ui.map.CareemMapView
import com.example.ui.theme.GoldRating
import com.example.ui.theme.LahzathaEmeraldDeep
import com.example.ui.theme.LahzathaGreen
import com.example.ui.theme.LahzathaGreenAccent
import com.example.ui.theme.LahzathaGreenDark
import com.example.ui.theme.RedEmergency
import com.example.ui.viewmodel.UiState

@Composable
fun CaptainScreen(
    state: UiState,
    onToggleOnline: () -> Unit,
    onAcceptRide: () -> Unit,
    onDeclineRide: () -> Unit,
    onAdvanceStep: () -> Unit,
    onSettleDebt: () -> Unit,
    onOpenSupportChat: () -> Unit,
    onOpenSos: () -> Unit,
    onSubmitDriverApplication: (fullName: String, nationalId: String, phone: String, vehicleType: String, carModel: String, plateNumber: String, carColor: String) -> Unit = { _, _, _, _, _, _, _ -> }
) {
    var showGoldHistoryDialog by remember { mutableStateOf(false) }
    var showDriverRegistrationDialog by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("captain_screen")
    ) {
        // Interactive Map
        CareemMapView(
            modifier = Modifier.fillMaxSize(),
            pickupX = state.currentRide?.pickupX ?: 0.35f,
            pickupY = state.currentRide?.pickupY ?: 0.55f,
            dropoffX = state.currentRide?.dropoffX ?: 0.75f,
            dropoffY = state.currentRide?.dropoffY ?: 0.25f,
            hasRoute = state.currentRide != null,
            rideStatus = state.currentRide?.status ?: RideStatus.IDLE,
            activeCarProgress = state.activeCarProgress,
            isCaptainMode = true
        )

        // Top Overlay: Online Switcher & Hero Banner
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Online/Offline Pill with Captain Profile
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(
                                    if (state.captainProfile.isOnline) LahzathaGreen.copy(alpha = 0.2f)
                                    else Color.Gray.copy(alpha = 0.2f)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.DirectionsCar,
                                contentDescription = null,
                                tint = if (state.captainProfile.isOnline) LahzathaGreenDark else Color.Gray,
                                modifier = Modifier.size(26.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = state.captainProfile.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = null,
                                        tint = GoldRating,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = "${state.captainProfile.rating}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Text(
                                text = if (state.captainProfile.isOnline) "متصل الآن • بانتظار الرحلات" else "غير متصل • اضغط للتشغيل",
                                fontSize = 11.sp,
                                color = if (state.captainProfile.isOnline) LahzathaGreenDark else Color.Gray,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Switch(
                        checked = state.captainProfile.isOnline,
                        onCheckedChange = { onToggleOnline() },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = LahzathaGreenDark,
                            uncheckedThumbColor = Color.White,
                            uncheckedTrackColor = Color.Gray
                        ),
                        modifier = Modifier.testTag("captain_online_switch")
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Quick Stats Bar: Today's Earnings & Commission Debt Warning
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Today's Net Earnings
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)),
                    elevation = CardDefaults.cardElevation(3.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "أرباح اليوم (${state.captainTodayTrips} رحلات)",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${state.captainTodayEarnings.toInt()} ج.م",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = LahzathaGreenDark
                        )
                    }
                }

                // Commission Debt Card (with Settle Button)
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (state.captainProfile.commissionDebt > 0)
                            RedEmergency.copy(alpha = 0.12f) else LahzathaGreen.copy(alpha = 0.12f)
                    ),
                    elevation = CardDefaults.cardElevation(3.dp),
                    modifier = Modifier
                        .weight(1.2f)
                        .clickable { onSettleDebt() }
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "مديونية عمولة التطبيق",
                                fontSize = 10.sp,
                                color = if (state.captainProfile.commissionDebt > 0) RedEmergency else LahzathaGreenDark
                            )
                            Text(
                                text = "${state.captainProfile.commissionDebt} ج.م",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (state.captainProfile.commissionDebt > 0) RedEmergency else LahzathaGreenDark
                            )
                        }
                        if (state.captainProfile.commissionDebt > 0) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = RedEmergency
                            ) {
                                Text(
                                    text = "سداد",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Row 2: Gold Rewards & Driver Documents Verification
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Gold Incentives Card
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = GoldRating.copy(alpha = 0.15f)
                    ),
                    elevation = CardDefaults.cardElevation(3.dp),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { showGoldHistoryDialog = true }
                        .testTag("captain_gold_rewards_card")
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(GoldRating.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Stars,
                                contentDescription = null,
                                tint = Color(0xFFE65100),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "حوافز الذهب 🏅",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFE65100)
                            )
                            Text(
                                text = "${state.captainProfile.goldBalanceGrams} جرام ذهب",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFFBF360C)
                            )
                        }
                    }
                }

                // Driver Documents Verification Card
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)
                    ),
                    elevation = CardDefaults.cardElevation(3.dp),
                    modifier = Modifier
                        .weight(1.1f)
                        .clickable { showDriverRegistrationDialog = true }
                        .testTag("captain_documents_card")
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(LahzathaGreen.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Assignment,
                                contentDescription = null,
                                tint = LahzathaGreenDark,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "توثيق أوراق الكابتن",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            val latestApp = state.driverApplicationsList.firstOrNull()
                            val statusText = when (latestApp?.status) {
                                com.example.data.model.ApplicationStatus.APPROVED -> "معتمد ومقبول ✅"
                                com.example.data.model.ApplicationStatus.PENDING -> "قيد الفحص ⏳"
                                com.example.data.model.ApplicationStatus.REJECTED -> "مرفوض - إعادة رفع ⚠️"
                                else -> "رفع الرخص والبطاقة 📤"
                            }
                            Text(
                                text = statusText,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (latestApp?.status) {
                                    com.example.data.model.ApplicationStatus.APPROVED -> LahzathaGreenDark
                                    com.example.data.model.ApplicationStatus.REJECTED -> RedEmergency
                                    else -> Color(0xFFE65100)
                                }
                            )
                        }
                    }
                }
            }
        }

        // Bottom Sheets: Either Incoming Request or Active Ride Controller
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
        ) {
            // Case 1: Incoming Request
            AnimatedVisibility(
                visible = state.incomingRideRequest != null,
                enter = slideInVertically { it } + fadeIn(),
                exit = slideOutVertically { it } + fadeOut()
            ) {
                state.incomingRideRequest?.let { request ->
                    IncomingRideRequestCard(
                        request = request,
                        countdown = state.requestCountdownSeconds,
                        onAccept = onAcceptRide,
                        onDecline = onDeclineRide
                    )
                }
            }

            // Case 2: Active Ride Navigation Sheet
            AnimatedVisibility(
                visible = state.currentRide != null && state.incomingRideRequest == null,
                enter = slideInVertically { it } + fadeIn(),
                exit = slideOutVertically { it } + fadeOut()
            ) {
                state.currentRide?.let { ride ->
                    ActiveCaptainRideSheet(
                        ride = ride,
                        onAdvanceStep = onAdvanceStep,
                        onOpenSupportChat = onOpenSupportChat,
                        onOpenSos = onOpenSos
                    )
                }
            }
        }
    }

    // Gold Rewards History Dialog
    if (showGoldHistoryDialog) {
        AlertDialog(
            onDismissRequest = { showGoldHistoryDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(GoldRating.copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stars,
                            contentDescription = null,
                            tint = Color(0xFFE65100),
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "سجل مكافآت وحوافز الذهب 🏅",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = Color(0xFFBF360C)
                        )
                        Text(
                            text = "تقدير التميز وتحقيق أعلى التقييمات",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            text = {
                Column {
                    // Gold Balance Summary Card
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = GoldRating.copy(alpha = 0.15f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "إجمالي رصيد سبائك وجرامات الذهب المكتسبة",
                                fontSize = 11.sp,
                                color = Color(0xFF8D6E63)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${state.captainProfile.goldBalanceGrams} جرام عيار 21",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color(0xFFE65100)
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "القيمة السوقية التقريبية: ~${(state.captainProfile.goldBalanceGrams * 3800).toInt()} ج.م",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = LahzathaGreenDark
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "كشف المكافآت المرسلة من الإدارة:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(state.goldRewardsHistory) { reward ->
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = reward.reason,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "${reward.date} • تعادل ~${reward.equivalentEgp.toInt()} ج.م",
                                            fontSize = 10.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = GoldRating.copy(alpha = 0.3f)
                                    ) {
                                        Text(
                                            text = "+${reward.goldGrams} جرام",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = Color(0xFFBF360C),
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showGoldHistoryDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = LahzathaGreenDark)
                ) {
                    Text("إغلاق")
                }
            }
        )
    }

    // Driver Registration & Document Uploading Dialog
    if (showDriverRegistrationDialog) {
        var fullName by remember { mutableStateOf(state.captainProfile.name) }
        var nationalId by remember { mutableStateOf("29408151203498") }
        var phone by remember { mutableStateOf(state.captainProfile.phone) }
        var vehicleType by remember { mutableStateOf("سيارة ملاكي") }
        var carModel by remember { mutableStateOf(state.captainProfile.carModel) }
        var plateNumber by remember { mutableStateOf(state.captainProfile.plateNumber) }
        var carColor by remember { mutableStateOf(state.captainProfile.carColor) }

        var licenseFrontUploaded by remember { mutableStateOf(true) }
        var licenseBackUploaded by remember { mutableStateOf(true) }
        var carLicenseUploaded by remember { mutableStateOf(true) }
        var nationalIdUploaded by remember { mutableStateOf(true) }

        val latestApp = state.driverApplicationsList.firstOrNull()

        AlertDialog(
            onDismissRequest = { showDriverRegistrationDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(LahzathaGreen.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Assignment,
                            contentDescription = null,
                            tint = LahzathaGreenDark,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "تسجيل كابتن ورفع المستندات 📋",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = LahzathaGreenDark
                        )
                        Text(
                            text = "الرخص والبطاقة وتفاصيل وسيلة التنقل",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            text = {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(380.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Application Status Banner if exists
                    item {
                        if (latestApp != null) {
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = when (latestApp.status) {
                                        com.example.data.model.ApplicationStatus.APPROVED -> LahzathaGreen.copy(alpha = 0.15f)
                                        com.example.data.model.ApplicationStatus.REJECTED -> RedEmergency.copy(alpha = 0.15f)
                                        else -> Color(0xFFFFF3E0)
                                    }
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = "حالة طلب التوثيق الحالية: ${latestApp.status.titleAr}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = when (latestApp.status) {
                                            com.example.data.model.ApplicationStatus.APPROVED -> LahzathaGreenDark
                                            com.example.data.model.ApplicationStatus.REJECTED -> RedEmergency
                                            else -> Color(0xFFE65100)
                                        }
                                    )
                                    if (latestApp.status == com.example.data.model.ApplicationStatus.REJECTED && latestApp.rejectionReason != null) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "سبب الرفض: ${latestApp.rejectionReason}",
                                            fontSize = 11.sp,
                                            color = RedEmergency
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Section 1: Captain Personal Info
                    item {
                        Text(
                            text = "1. البيانات الشخصية للكابتن:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = LahzathaGreenDark
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = fullName,
                            onValueChange = { fullName = it },
                            label = { Text("الاسم الرباعي كاملاً") },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = LahzathaGreenDark) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = nationalId,
                            onValueChange = { nationalId = it },
                            label = { Text("الرقم القومي (14 رقم)") },
                            leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null, tint = LahzathaGreenDark) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    item {
                        OutlinedTextField(
                            value = phone,
                            onValueChange = { phone = it },
                            label = { Text("رقم الهاتف المحمول") },
                            leadingIcon = { Icon(Icons.Default.Call, contentDescription = null, tint = LahzathaGreenDark) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    // Section 2: Vehicle Details
                    item {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "2. بيانات وسيلة التنقل والسيارة:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = LahzathaGreenDark
                        )
                    }

                    item {
                        // Vehicle Type selector chips
                        Text(
                            text = "نوع وسيلة التنقل:",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            listOf("سيارة ملاكي", "سكوتر", "تاكسي", "فان عائلي").forEach { type ->
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (vehicleType == type) LahzathaGreenDark else MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { vehicleType = type }
                                ) {
                                    Text(
                                        text = type,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (vehicleType == type) Color.White else MaterialTheme.colorScheme.onSurface,
                                        modifier = Modifier.padding(vertical = 6.dp, horizontal = 2.dp),
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }

                    item {
                        OutlinedTextField(
                            value = carModel,
                            onValueChange = { carModel = it },
                            label = { Text("موديل وسنة الصنع (مثال: نيسان صني 2023)") },
                            leadingIcon = { Icon(Icons.Default.DirectionsCar, contentDescription = null, tint = LahzathaGreenDark) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = plateNumber,
                                onValueChange = { plateNumber = it },
                                label = { Text("رقم اللوحة المعدنية") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = carColor,
                                onValueChange = { carColor = it },
                                label = { Text("اللون") },
                                singleLine = true,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // Section 3: Required Upload Documents (الـ 4 أوراق المطلوبة)
                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "3. المستندات والأوراق الرسمية المطلوبة للقبول:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = LahzathaGreenDark
                        )
                        Text(
                            text = "يجب رفع صور واضحة للرخص وبطاقة الرقم القومي",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Doc 1: Front of Driver License
                    item {
                        DocumentUploadRow(
                            title = "صورة وجه رخصة القيادة",
                            description = "يجب أن تكون سارية والبيانات والصورة واضحة",
                            isUploaded = licenseFrontUploaded,
                            onToggleUpload = { licenseFrontUploaded = !licenseFrontUploaded }
                        )
                    }

                    // Doc 2: Back of Driver License
                    item {
                        DocumentUploadRow(
                            title = "صورة ظهر رخصة القيادة",
                            description = "توضيح تاريخ الانتهاء ونوع رخصة القيادة",
                            isUploaded = licenseBackUploaded,
                            onToggleUpload = { licenseBackUploaded = !licenseBackUploaded }
                        )
                    }

                    // Doc 3: Vehicle Registration
                    item {
                        DocumentUploadRow(
                            title = "صورة رخصة تسيير المركبة / السيارة",
                            description = "رخصة السيارة أو السكوتر سارية وباسم الكابتن أو بتوكيل",
                            isUploaded = carLicenseUploaded,
                            onToggleUpload = { carLicenseUploaded = !carLicenseUploaded }
                        )
                    }

                    // Doc 4: National ID Card
                    item {
                        DocumentUploadRow(
                            title = "صورة بطاقة الرقم القومي (الوجهين)",
                            description = "بطاقة الرقم القومي سارية المفعول لتأكيد الهوية",
                            isUploaded = nationalIdUploaded,
                            onToggleUpload = { nationalIdUploaded = !nationalIdUploaded }
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onSubmitDriverApplication(
                            fullName,
                            nationalId,
                            phone,
                            vehicleType,
                            carModel,
                            plateNumber,
                            carColor
                        )
                        showDriverRegistrationDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = LahzathaGreenDark),
                    modifier = Modifier.testTag("submit_driver_app_btn")
                ) {
                    Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("إرسال الأوراق للاعتماد والتشغيل", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showDriverRegistrationDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
private fun DocumentUploadRow(
    title: String,
    description: String,
    isUploaded: Boolean,
    onToggleUpload: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isUploaded) LahzathaGreen.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surfaceVariant
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggleUpload() }
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(if (isUploaded) LahzathaGreenDark else Color.Gray.copy(alpha = 0.3f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isUploaded) Icons.Default.CheckCircle else Icons.Default.CameraAlt,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Text(
                        text = description,
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isUploaded) LahzathaGreenDark else Color.Gray.copy(alpha = 0.2f)
            ) {
                Text(
                    text = if (isUploaded) "تم الرفع بنجاح ✅" else "اضغط للرفع 📷",
                    color = if (isUploaded) Color.White else MaterialTheme.colorScheme.onSurface,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }
    }
}


@Composable
private fun IncomingRideRequestCard(
    request: com.example.data.model.RideItem,
    countdown: Int,
    onAccept: () -> Unit,
    onDecline: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("incoming_request_card")
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            // Timer bar
            LinearProgressIndicator(
                progress = { countdown / 15f },
                color = LahzathaGreenDark,
                trackColor = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp))
            )

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(GoldRating.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.HourglassTop,
                            contentDescription = null,
                            tint = GoldRating,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "طلب رحلة جديد! ($countdown ثوانٍ)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = LahzathaGreen.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = request.category.titleAr,
                        color = LahzathaGreenDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Pickup & Destination
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF00C853))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "الالتقاء: ${request.pickupAddress}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(RedEmergency)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "الوجهة: ${request.dropoffAddress}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Fare breakdown for Captain & App Commission
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "صافي ربح الكابتن",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "${request.captainNetEarnings.toInt()} ج.م",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = LahzathaGreenDark
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "إجمالي الأجرة: ${request.totalFare.toInt()} ج.م (كاش)",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "عمولة التطبيق المستقطعة: ${request.appCommissionAmount.toInt()} ج.م (20%)",
                            fontSize = 11.sp,
                            color = RedEmergency,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Action Buttons: Accept / Decline
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = onDecline,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Gray),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("decline_request_btn")
                ) {
                    Text("تجاهل")
                }

                Button(
                    onClick = onAccept,
                    colors = ButtonDefaults.buttonColors(containerColor = LahzathaGreenDark),
                    modifier = Modifier
                        .weight(2f)
                        .height(48.dp)
                        .testTag("accept_request_btn")
                ) {
                    Icon(Icons.Default.Check, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("قبول الطلب فوراً", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ActiveCaptainRideSheet(
    ride: com.example.data.model.RideItem,
    onAdvanceStep: () -> Unit,
    onOpenSupportChat: () -> Unit,
    onOpenSos: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("active_captain_ride_sheet")
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            // Status and Passenger Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(LahzathaGreen.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = LahzathaGreenDark,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "الراكب: عميل لحظتها",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = ride.status.titleAr,
                            fontSize = 12.sp,
                            color = LahzathaGreenDark,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Row {
                    IconButton(
                        onClick = onOpenSupportChat,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Icon(Icons.Default.Chat, contentDescription = "محادثة", tint = LahzathaGreenDark)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = onOpenSos,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(RedEmergency.copy(alpha = 0.15f))
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = "SOS", tint = RedEmergency)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Navigation Instructions Box
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = LahzathaEmeraldDeep,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Navigation,
                        contentDescription = null,
                        tint = LahzathaGreenAccent,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = when (ride.status) {
                                RideStatus.CAPTAIN_ASSIGNED -> "اتجه إلى: ${ride.pickupAddress}"
                                RideStatus.ARRIVED -> "أنت في نقطة الالتقاء، بانتظار ركوب العميل"
                                RideStatus.IN_PROGRESS -> "متوجهون إلى: ${ride.dropoffAddress}"
                                else -> "انتهت الرحلة"
                            },
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "المسافة: ${ride.distanceKm} كم • متوقع 12 دقيقة",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Action Step Button
            val buttonText = when (ride.status) {
                RideStatus.CAPTAIN_ASSIGNED -> "وصلت لنقطة الالتقاء"
                RideStatus.ARRIVED -> "بدء الرحلة الآن"
                RideStatus.IN_PROGRESS -> "إنهاء الرحلة وتحصيل ${ride.totalFare} ج.م"
                else -> "تم إنهاء الرحلة"
            }

            Button(
                onClick = onAdvanceStep,
                colors = ButtonDefaults.buttonColors(containerColor = LahzathaGreenDark),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("captain_advance_step_btn")
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = buttonText,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
