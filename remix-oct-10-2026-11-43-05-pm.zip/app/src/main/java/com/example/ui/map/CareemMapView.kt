package com.example.ui.map

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Traffic
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RideStatus
import kotlinx.coroutines.delay
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class SimulatedCar(
    var id: Int,
    var x: Float, // 0..1 normalized map coords
    var y: Float,
    var angle: Float,
    var speed: Float,
    var waypoints: List<Offset>,
    var currentWaypointIndex: Int = 0
)

@Composable
fun CareemMapView(
    modifier: Modifier = Modifier,
    pickupX: Float = 0.35f,
    pickupY: Float = 0.55f,
    dropoffX: Float = 0.75f,
    dropoffY: Float = 0.25f,
    hasRoute: Boolean = true,
    rideStatus: RideStatus = RideStatus.IDLE,
    activeCarProgress: Float = 0f, // 0f..1f for moving assigned captain along route
    isCaptainMode: Boolean = false,
    onMapClicked: (Float, Float) -> Unit = { _, _ -> }
) {
    // Map view state (Pan & Zoom)
    var panOffsetX by remember { mutableFloatStateOf(0f) }
    var panOffsetY by remember { mutableFloatStateOf(0f) }
    var zoomScale by remember { mutableFloatStateOf(1.0f) }
    var isNightMode by remember { mutableStateOf(false) }
    var showTraffic by remember { mutableStateOf(true) }

    // Pulse animation for user location marker
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseRadius by infiniteTransition.animateFloat(
        initialValue = 10f,
        targetValue = 35f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseRadius"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulseAlpha"
    )
    val routePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 50f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "routeDash"
    )

    // Animated nearby cars simulating actual live traffic in the city
    val nearbyCars = remember {
        mutableStateListOf(
            SimulatedCar(
                id = 1,
                x = 0.30f,
                y = 0.50f,
                angle = 45f,
                speed = 0.0018f,
                waypoints = listOf(
                    Offset(0.30f, 0.50f),
                    Offset(0.38f, 0.45f),
                    Offset(0.45f, 0.50f),
                    Offset(0.35f, 0.60f)
                )
            ),
            SimulatedCar(
                id = 2,
                x = 0.40f,
                y = 0.60f,
                angle = 120f,
                speed = 0.0015f,
                waypoints = listOf(
                    Offset(0.40f, 0.60f),
                    Offset(0.48f, 0.65f),
                    Offset(0.40f, 0.75f),
                    Offset(0.32f, 0.65f)
                )
            ),
            SimulatedCar(
                id = 3,
                x = 0.25f,
                y = 0.40f,
                angle = 270f,
                speed = 0.0022f,
                waypoints = listOf(
                    Offset(0.25f, 0.40f),
                    Offset(0.20f, 0.45f),
                    Offset(0.25f, 0.55f),
                    Offset(0.30f, 0.48f)
                )
            ),
            SimulatedCar(
                id = 4,
                x = 0.60f,
                y = 0.35f,
                angle = 90f,
                speed = 0.0019f,
                waypoints = listOf(
                    Offset(0.60f, 0.35f),
                    Offset(0.68f, 0.32f),
                    Offset(0.72f, 0.42f),
                    Offset(0.60f, 0.45f)
                )
            ),
            SimulatedCar(
                id = 5,
                x = 0.50f,
                y = 0.25f,
                angle = 180f,
                speed = 0.0016f,
                waypoints = listOf(
                    Offset(0.50f, 0.25f),
                    Offset(0.55f, 0.30f),
                    Offset(0.45f, 0.35f),
                    Offset(0.42f, 0.28f)
                )
            )
        )
    }

    // Car simulation loop
    LaunchedEffect(Unit) {
        while (true) {
            delay(50)
            for (car in nearbyCars) {
                val target = car.waypoints[car.currentWaypointIndex]
                val dx = target.x - car.x
                val dy = target.y - car.y
                val dist = sqrt(dx * dx + dy * dy)
                if (dist < 0.02f) {
                    car.currentWaypointIndex = (car.currentWaypointIndex + 1) % car.waypoints.size
                } else {
                    val angleRad = atan2(dy, dx)
                    car.angle = Math.toDegrees(angleRad.toDouble()).toFloat()
                    car.x += (cos(angleRad) * car.speed).toFloat()
                    car.y += (sin(angleRad) * car.speed).toFloat()
                }
            }
        }
    }

    val textMeasurer = rememberTextMeasurer()

    Box(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    panOffsetX += dragAmount.x
                    panOffsetY += dragAmount.y
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            // Background / City ground
            val bgColor = if (isNightMode) Color(0xFF131B16) else Color(0xFFEFF5F1)
            drawRect(color = bgColor)

            // Parks and green areas (Careem-style greenery)
            val parkColor = if (isNightMode) Color(0xFF17291E) else Color(0xFFD6EAD8)
            drawRoundRect(
                color = parkColor,
                topLeft = Offset(width * 0.05f + panOffsetX, height * 0.08f + panOffsetY),
                size = Size(width * 0.28f * zoomScale, height * 0.18f * zoomScale),
                cornerRadius = CornerRadius(24f, 24f)
            )
            drawRoundRect(
                color = parkColor,
                topLeft = Offset(width * 0.58f + panOffsetX, height * 0.65f + panOffsetY),
                size = Size(width * 0.35f * zoomScale, height * 0.22f * zoomScale),
                cornerRadius = CornerRadius(24f, 24f)
            )

            // Water River (The Nile / Waterway)
            val waterColor = if (isNightMode) Color(0xFF132A33) else Color(0xFFC7E2E9)
            val riverPath = Path().apply {
                moveTo(width * 0.48f + panOffsetX, 0f)
                cubicTo(
                    width * 0.52f + panOffsetX, height * 0.3f + panOffsetY,
                    width * 0.42f + panOffsetX, height * 0.7f + panOffsetY,
                    width * 0.46f + panOffsetX, height
                )
            }
            drawPath(
                path = riverPath,
                color = waterColor,
                style = Stroke(width = 46f * zoomScale, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )

            // Building Blocks / Districts
            val blockColor = if (isNightMode) Color(0xFF1B2620) else Color(0xFFE4EDE7)
            val blockBorder = if (isNightMode) Color(0xFF23352B) else Color(0xFFD3E0D8)
            val blocks = listOf(
                Offset(0.12f, 0.32f) to Size(0.18f, 0.12f),
                Offset(0.15f, 0.68f) to Size(0.16f, 0.15f),
                Offset(0.68f, 0.12f) to Size(0.22f, 0.16f),
                Offset(0.72f, 0.42f) to Size(0.20f, 0.18f),
                Offset(0.28f, 0.15f) to Size(0.14f, 0.12f)
            )
            for ((pos, bSize) in blocks) {
                val topLeft = Offset(width * pos.x + panOffsetX, height * pos.y + panOffsetY)
                val rectSize = Size(width * bSize.width * zoomScale, height * bSize.height * zoomScale)
                drawRoundRect(
                    color = blockColor,
                    topLeft = topLeft,
                    size = rectSize,
                    cornerRadius = CornerRadius(12f, 12f)
                )
                drawRoundRect(
                    color = blockBorder,
                    topLeft = topLeft,
                    size = rectSize,
                    cornerRadius = CornerRadius(12f, 12f),
                    style = Stroke(width = 2f)
                )
            }

            // Secondary Roads (Grid)
            val secondaryRoadColor = if (isNightMode) Color(0xFF26382E) else Color(0xFFFFFFFF)
            val gridYs = listOf(0.15f, 0.28f, 0.42f, 0.58f, 0.72f, 0.88f)
            for (gy in gridYs) {
                drawLine(
                    color = secondaryRoadColor,
                    start = Offset(0f, height * gy + panOffsetY),
                    end = Offset(width, height * gy + panOffsetY),
                    strokeWidth = 14f * zoomScale,
                    cap = StrokeCap.Round
                )
            }
            val gridXs = listOf(0.10f, 0.26f, 0.42f, 0.62f, 0.82f)
            for (gx in gridXs) {
                drawLine(
                    color = secondaryRoadColor,
                    start = Offset(width * gx + panOffsetX, 0f),
                    end = Offset(width * gx + panOffsetX, height),
                    strokeWidth = 14f * zoomScale,
                    cap = StrokeCap.Round
                )
            }

            // Primary Major Avenues & Ring Highways (شوارع رئيسية ومحاور)
            val highwayBorderColor = if (isNightMode) Color(0xFF334A3D) else Color(0xFFD6DEC9)
            val highwayFillColor = if (isNightMode) Color(0xFF2A3D33) else Color(0xFFFFF9E6)

            // Diagonal Ring Highway
            val highwayPath = Path().apply {
                moveTo(0f, height * 0.75f + panOffsetY)
                cubicTo(
                    width * 0.35f + panOffsetX, height * 0.70f + panOffsetY,
                    width * 0.65f + panOffsetX, height * 0.35f + panOffsetY,
                    width, height * 0.20f + panOffsetY
                )
            }
            drawPath(
                path = highwayPath,
                color = highwayBorderColor,
                style = Stroke(width = 32f * zoomScale, cap = StrokeCap.Round)
            )
            drawPath(
                path = highwayPath,
                color = highwayFillColor,
                style = Stroke(width = 24f * zoomScale, cap = StrokeCap.Round)
            )

            // Main East-West Boulevard
            drawLine(
                color = highwayBorderColor,
                start = Offset(0f, height * 0.50f + panOffsetY),
                end = Offset(width, height * 0.50f + panOffsetY),
                strokeWidth = 28f * zoomScale
            )
            drawLine(
                color = highwayFillColor,
                start = Offset(0f, height * 0.50f + panOffsetY),
                end = Offset(width, height * 0.50f + panOffsetY),
                strokeWidth = 22f * zoomScale
            )

            // Traffic overlays if enabled (Careem live traffic colors: green / orange / red)
            if (showTraffic) {
                drawLine(
                    color = Color(0xFF00E676).copy(alpha = 0.85f),
                    start = Offset(width * 0.1f + panOffsetX, height * 0.50f + panOffsetY),
                    end = Offset(width * 0.45f + panOffsetX, height * 0.50f + panOffsetY),
                    strokeWidth = 6f * zoomScale,
                    cap = StrokeCap.Round
                )
                drawLine(
                    color = Color(0xFFFF9100).copy(alpha = 0.85f),
                    start = Offset(width * 0.55f + panOffsetX, height * 0.50f + panOffsetY),
                    end = Offset(width * 0.85f + panOffsetX, height * 0.50f + panOffsetY),
                    strokeWidth = 6f * zoomScale,
                    cap = StrokeCap.Round
                )
                drawLine(
                    color = Color(0xFF00E676).copy(alpha = 0.85f),
                    start = Offset(width * 0.26f + panOffsetX, height * 0.2f + panOffsetY),
                    end = Offset(width * 0.26f + panOffsetX, height * 0.6f + panOffsetY),
                    strokeWidth = 6f * zoomScale,
                    cap = StrokeCap.Round
                )
            }

            // Road Labels in Arabic
            val labelStyle = TextStyle(
                color = if (isNightMode) Color(0xFF8AA694) else Color(0xFF6B7E72),
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
            )
            drawText(
                textMeasurer = textMeasurer,
                text = "شارع التحرير",
                topLeft = Offset(width * 0.12f + panOffsetX, height * 0.48f + panOffsetY),
                style = labelStyle
            )
            drawText(
                textMeasurer = textMeasurer,
                text = "محور 26 يوليو",
                topLeft = Offset(width * 0.62f + panOffsetX, height * 0.32f + panOffsetY),
                style = labelStyle
            )
            drawText(
                textMeasurer = textMeasurer,
                text = "كورنيش النيل",
                topLeft = Offset(width * 0.44f + panOffsetX, height * 0.12f + panOffsetY),
                style = labelStyle
            )

            // Convert normalized coordinates to screen canvas coords
            val pX = width * pickupX + panOffsetX
            val pY = height * pickupY + panOffsetY
            val dX = width * dropoffX + panOffsetX
            val dY = height * dropoffY + panOffsetY

            // Draw Route Polyline if active or booking
            if (hasRoute) {
                val routePath = Path().apply {
                    moveTo(pX, pY)
                    // Multi-segment realistic city route with turns
                    val mid1X = pX + (dX - pX) * 0.35f
                    val mid1Y = pY
                    val mid2X = mid1X
                    val mid2Y = dY
                    lineTo(mid1X, mid1Y)
                    lineTo(mid2X, mid2Y)
                    lineTo(dX, dY)
                }

                // Outer route glow (Emerald green)
                drawPath(
                    path = routePath,
                    color = Color(0xFF00E676).copy(alpha = 0.35f),
                    style = Stroke(width = 22f * zoomScale, cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
                // Route core line
                drawPath(
                    path = routePath,
                    color = Color(0xFF00C853),
                    style = Stroke(width = 10f * zoomScale, cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
                // Animated dashed flow
                drawPath(
                    path = routePath,
                    color = Color.White,
                    style = Stroke(
                        width = 4f * zoomScale,
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(25f, 25f), routePhase)
                    )
                )
            }

            // Draw Nearby Roaming Captain Cars
            for (car in nearbyCars) {
                val carScreenX = width * car.x + panOffsetX
                val carScreenY = height * car.y + panOffsetY
                drawCarMarker(
                    x = carScreenX,
                    y = carScreenY,
                    angle = car.angle,
                    zoom = zoomScale,
                    color = Color(0xFF0A2E1D),
                    isNight = isNightMode
                )
            }

            // Draw Pickup Marker (نقطة الانطلاق)
            // Pulse circle
            drawCircle(
                color = Color(0xFF00E676).copy(alpha = pulseAlpha),
                radius = pulseRadius * zoomScale,
                center = Offset(pX, pY)
            )
            // Inner green badge
            drawCircle(
                color = Color(0xFF00C853),
                radius = 16f * zoomScale,
                center = Offset(pX, pY)
            )
            drawCircle(
                color = Color.White,
                radius = 7f * zoomScale,
                center = Offset(pX, pY)
            )
            // Pickup label badge
            val pickupBadgeBg = if (isNightMode) Color(0xFF15221B) else Color.White
            val badgeWidth = 140f * zoomScale
            val badgeHeight = 44f * zoomScale
            drawRoundRect(
                color = pickupBadgeBg,
                topLeft = Offset(pX - badgeWidth / 2, pY - 56f * zoomScale),
                size = Size(badgeWidth, badgeHeight),
                cornerRadius = CornerRadius(16f, 16f)
            )
            drawRoundRect(
                color = Color(0xFF00C853),
                topLeft = Offset(pX - badgeWidth / 2, pY - 56f * zoomScale),
                size = Size(badgeWidth, badgeHeight),
                cornerRadius = CornerRadius(16f, 16f),
                style = Stroke(width = 2.5f)
            )
            drawText(
                textMeasurer = textMeasurer,
                text = "موقعك الحالي",
                topLeft = Offset(pX - badgeWidth / 2 + 20f * zoomScale, pY - 50f * zoomScale),
                style = TextStyle(
                    color = if (isNightMode) Color.White else Color(0xFF0A2E1D),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            )

            // Draw Dropoff Marker (وجهة الوصول)
            if (hasRoute) {
                drawCircle(
                    color = Color(0xFFFF3D57).copy(alpha = 0.25f),
                    radius = 22f * zoomScale,
                    center = Offset(dX, dY)
                )
                drawCircle(
                    color = Color(0xFFFF3D57),
                    radius = 14f * zoomScale,
                    center = Offset(dX, dY)
                )
                drawCircle(
                    color = Color.White,
                    radius = 6f * zoomScale,
                    center = Offset(dX, dY)
                )
                // Dropoff label badge
                val dropBadgeWidth = 130f * zoomScale
                val dropBadgeHeight = 44f * zoomScale
                drawRoundRect(
                    color = pickupBadgeBg,
                    topLeft = Offset(dX - dropBadgeWidth / 2, dY - 56f * zoomScale),
                    size = Size(dropBadgeWidth, dropBadgeHeight),
                    cornerRadius = CornerRadius(16f, 16f)
                )
                drawRoundRect(
                    color = Color(0xFFFF3D57),
                    topLeft = Offset(dX - dropBadgeWidth / 2, dY - 56f * zoomScale),
                    size = Size(dropBadgeWidth, dropBadgeHeight),
                    cornerRadius = CornerRadius(16f, 16f),
                    style = Stroke(width = 2.5f)
                )
                drawText(
                    textMeasurer = textMeasurer,
                    text = "وجهة الوصول",
                    topLeft = Offset(dX - dropBadgeWidth / 2 + 18f * zoomScale, dY - 50f * zoomScale),
                    style = TextStyle(
                        color = if (isNightMode) Color.White else Color(0xFF1E1E1E),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            // If a ride is in progress, draw the Assigned Captain's Car gliding along the path!
            if (rideStatus == RideStatus.CAPTAIN_ASSIGNED ||
                rideStatus == RideStatus.ARRIVED ||
                rideStatus == RideStatus.IN_PROGRESS
            ) {
                // Calculate position along path based on progress
                val activeCarX: Float
                val activeCarY: Float
                val activeAngle: Float

                if (rideStatus == RideStatus.CAPTAIN_ASSIGNED) {
                    // Car driving towards pickup
                    val startApproachX = pX - 120f
                    val startApproachY = pY + 140f
                    activeCarX = startApproachX + (pX - startApproachX) * activeCarProgress
                    activeCarY = startApproachY + (pY - startApproachY) * activeCarProgress
                    activeAngle = -50f
                } else if (rideStatus == RideStatus.ARRIVED) {
                    activeCarX = pX
                    activeCarY = pY
                    activeAngle = 0f
                } else {
                    // In Progress driving to dropoff
                    val mid1X = pX + (dX - pX) * 0.35f
                    val mid1Y = pY
                    val mid2X = mid1X
                    val mid2Y = dY
                    if (activeCarProgress < 0.33f) {
                        val segProg = activeCarProgress / 0.33f
                        activeCarX = pX + (mid1X - pX) * segProg
                        activeCarY = pY
                        activeAngle = if (mid1X >= pX) 0f else 180f
                    } else if (activeCarProgress < 0.66f) {
                        val segProg = (activeCarProgress - 0.33f) / 0.33f
                        activeCarX = mid1X
                        activeCarY = mid1Y + (mid2Y - mid1Y) * segProg
                        activeAngle = if (mid2Y >= mid1Y) 90f else 270f
                    } else {
                        val segProg = (activeCarProgress - 0.66f) / 0.34f
                        activeCarX = mid2X + (dX - mid2X) * segProg
                        activeCarY = dY
                        activeAngle = if (dX >= mid2X) 0f else 180f
                    }
                }

                // Draw Captain Halo Badge
                drawCircle(
                    color = Color(0xFF00E676).copy(alpha = 0.4f),
                    radius = 28f * zoomScale,
                    center = Offset(activeCarX, activeCarY)
                )
                drawCarMarker(
                    x = activeCarX,
                    y = activeCarY,
                    angle = activeAngle,
                    zoom = zoomScale * 1.35f,
                    color = Color(0xFF00C853), // Special green car for assigned captain
                    isNight = isNightMode
                )
            }
        }

        // Map Control Floating Actions (Zoom in/out, Re-center, Night Mode, Traffic)
        Column(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 16.dp, end = 16.dp)
        ) {
            // Re-center Location Button
            FloatingActionButton(
                onClick = {
                    panOffsetX = 0f
                    panOffsetY = 0f
                    zoomScale = 1.0f
                },
                shape = CircleShape,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                elevation = FloatingActionButtonDefaults.elevation(4.dp),
                modifier = Modifier.size(46.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.MyLocation,
                    contentDescription = "موقعي الحالي"
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Night / Day Toggle
            FloatingActionButton(
                onClick = { isNightMode = !isNightMode },
                shape = CircleShape,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = if (isNightMode) Color(0xFFFFB300) else Color(0xFF455A64),
                elevation = FloatingActionButtonDefaults.elevation(4.dp),
                modifier = Modifier.size(46.dp)
            ) {
                Icon(
                    imageVector = if (isNightMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                    contentDescription = "نمط الخريطة"
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Traffic Toggle
            FloatingActionButton(
                onClick = { showTraffic = !showTraffic },
                shape = CircleShape,
                containerColor = if (showTraffic) Color(0xFF00C853) else MaterialTheme.colorScheme.surface,
                contentColor = if (showTraffic) Color.White else MaterialTheme.colorScheme.onSurface,
                elevation = FloatingActionButtonDefaults.elevation(4.dp),
                modifier = Modifier.size(46.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Traffic,
                    contentDescription = "حالة المرور"
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Zoom In
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 4.dp
            ) {
                Column {
                    IconButton(
                        onClick = { if (zoomScale < 2.5f) zoomScale += 0.2f },
                        modifier = Modifier.size(44.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "تكبير")
                    }
                    IconButton(
                        onClick = { if (zoomScale > 0.6f) zoomScale -= 0.2f },
                        modifier = Modifier.size(44.dp)
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "تصغير")
                    }
                }
            }
        }

        // Live Traffic Status Pill at the top
        Surface(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(top = 16.dp, start = 16.dp)
                .shadow(6.dp, RoundedCornerShape(20.dp)),
            shape = RoundedCornerShape(20.dp),
            color = if (isNightMode) Color(0xFF15221B) else Color.White
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF00E676))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (isCaptainMode) "الخريطة حية • طلبات متزايدة" else "حركة المرور سالكة • تتبع لحظي",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isNightMode) Color.White else Color(0xFF1E2E24)
                )
            }
        }
    }
}

private fun DrawScope.drawCarMarker(
    x: Float,
    y: Float,
    angle: Float,
    zoom: Float,
    color: Color,
    isNight: Boolean
) {
    rotate(degrees = angle, pivot = Offset(x, y)) {
        // Car shadow
        drawRoundRect(
            color = Color.Black.copy(alpha = 0.25f),
            topLeft = Offset(x - 14f * zoom, y - 26f * zoom + 3f),
            size = Size(28f * zoom, 52f * zoom),
            cornerRadius = CornerRadius(10f, 10f)
        )
        // Car body
        drawRoundRect(
            color = color,
            topLeft = Offset(x - 13f * zoom, y - 25f * zoom),
            size = Size(26f * zoom, 50f * zoom),
            cornerRadius = CornerRadius(10f, 10f)
        )
        // Windshield
        drawRoundRect(
            color = if (isNight) Color(0xFF4DB6AC) else Color(0xFF80DEEA),
            topLeft = Offset(x - 9f * zoom, y - 16f * zoom),
            size = Size(18f * zoom, 12f * zoom),
            cornerRadius = CornerRadius(4f, 4f)
        )
        // Rear window
        drawRoundRect(
            color = if (isNight) Color(0xFF4DB6AC) else Color(0xFF80DEEA),
            topLeft = Offset(x - 9f * zoom, y + 8f * zoom),
            size = Size(18f * zoom, 7f * zoom),
            cornerRadius = CornerRadius(3f, 3f)
        )
        // Headlights (glowing yellow at night)
        drawCircle(
            color = Color(0xFFFFEB3B),
            radius = 3f * zoom,
            center = Offset(x - 8f * zoom, y - 23f * zoom)
        )
        drawCircle(
            color = Color(0xFFFFEB3B),
            radius = 3f * zoom,
            center = Offset(x + 8f * zoom, y - 23f * zoom)
        )
    }
}
