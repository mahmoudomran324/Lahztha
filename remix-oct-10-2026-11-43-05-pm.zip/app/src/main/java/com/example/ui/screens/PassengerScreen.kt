package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.ElectricCar
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.PaymentType
import com.example.data.model.RideCategory
import com.example.data.model.RideStatus
import com.example.data.model.SavedPlace
import com.example.ui.map.CareemMapView
import com.example.ui.theme.GoldRating
import com.example.ui.theme.LahzathaEmeraldDeep
import com.example.ui.theme.LahzathaGreen
import com.example.ui.theme.LahzathaGreenDark
import com.example.ui.theme.RedEmergency
import com.example.ui.viewmodel.UiState

@Composable
fun PassengerScreen(
    state: UiState,
    popularDestinations: List<SavedPlace>,
    currentFare: Double,
    onSelectDestination: (SavedPlace) -> Unit,
    onSelectCategory: (RideCategory) -> Unit,
    onSelectVehicleCategory: (com.example.data.model.VehicleCategory) -> Unit = {},
    onSelectPayment: (PaymentType) -> Unit,
    onOpenPromoDialog: () -> Unit,
    onRequestRide: () -> Unit,
    onCancelRide: () -> Unit,
    onOpenSupportChat: () -> Unit,
    onOpenSos: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .testTag("passenger_screen")
    ) {
        // High-Fidelity Interactive Map with Animated Moving Cars & Route
        CareemMapView(
            modifier = Modifier.fillMaxSize(),
            pickupX = state.pickupX,
            pickupY = state.pickupY,
            dropoffX = state.dropoffX,
            dropoffY = state.dropoffY,
            hasRoute = true,
            rideStatus = state.currentRide?.status ?: RideStatus.IDLE,
            activeCarProgress = state.activeCarProgress,
            isCaptainMode = false
        )

        // Top Destination Search & Shortcuts Header (visible when idle)
        if (state.currentRide == null) {
            Column(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Search Input Card
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(LahzathaGreen)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = state.pickupAddress,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Divider(
                            modifier = Modifier.padding(vertical = 10.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        )

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(RedEmergency)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = state.dropoffAddress,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Popular Place Shortcuts
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    for (place in popularDestinations) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                            shadowElevation = 3.dp,
                            modifier = Modifier.clickable { onSelectDestination(place) }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Place,
                                    contentDescription = null,
                                    tint = LahzathaGreenDark,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = place.titleAr,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Bottom Sheets: 1. Booking Sheet (Idle), 2. Radar Searching, 3. Live Captain Tracking
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
        ) {
            when {
                state.currentRide == null -> {
                    // Ride Booking Bottom Sheet
                    PassengerBookingSheet(
                        state = state,
                        currentFare = currentFare,
                        onSelectCategory = onSelectCategory,
                        onSelectVehicleCategory = onSelectVehicleCategory,
                        onSelectPayment = onSelectPayment,
                        onOpenPromoDialog = onOpenPromoDialog,
                        onRequestRide = onRequestRide
                    )
                }

                state.currentRide?.status == RideStatus.SEARCHING -> {
                    // Radar Searching Sheet
                    SearchingRadarSheet(
                        secondsElapsed = state.searchSecondsElapsed,
                        onCancel = onCancelRide
                    )
                }

                else -> {
                    // Active Ride Tracking Sheet
                    state.currentRide?.let { ride ->
                        LiveTrackingSheet(
                            ride = ride,
                            onCancel = onCancelRide,
                            onOpenSupportChat = onOpenSupportChat,
                            onOpenSos = onOpenSos
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PassengerBookingSheet(
    state: UiState,
    currentFare: Double,
    onSelectCategory: (RideCategory) -> Unit,
    onSelectVehicleCategory: (com.example.data.model.VehicleCategory) -> Unit = {},
    onSelectPayment: (PaymentType) -> Unit,
    onOpenPromoDialog: () -> Unit,
    onRequestRide: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("passenger_booking_sheet")
    ) {
        Column(
            modifier = Modifier
                .padding(horizontal = 18.dp, vertical = 14.dp)
        ) {
            // Drag handle
            Box(
                modifier = Modifier
                    .width(42.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.Gray.copy(alpha = 0.4f))
                    .align(Alignment.CenterHorizontally)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Hero Promotional Banner Image
            Card(
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(90.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.lahzatha_hero_banner_1791560845965),
                    contentDescription = "بانر رحلات لحظتها",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Category Selection (Horizontal Cards)
            Text(
                text = "اختر فئة الرحلة:",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val enabledVehicles = state.vehicleCategories.filter { it.isEnabled }
                for (vCat in enabledVehicles) {
                    val isSelected = state.selectedVehicleCategory.id == vCat.id || state.selectedCategory.id == vCat.id
                    val catFare = Math.round(
                        (vCat.baseFare + (state.distanceKm * vCat.perKmRate)) *
                                (if (state.discountPercent > 0) (1.0 - state.discountPercent / 100.0) else 1.0)
                    )

                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (isSelected) LahzathaGreen.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = androidx.compose.foundation.BorderStroke(
                            2.dp,
                            if (isSelected) LahzathaGreenDark else Color.Transparent
                        ),
                        modifier = Modifier
                            .width(135.dp)
                            .clickable {
                                onSelectVehicleCategory(vCat)
                                val enumCat = RideCategory.values().find { it.id == vCat.id }
                                if (enumCat != null) onSelectCategory(enumCat)
                            }
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = when (vCat.vehicleType.uppercase()) {
                                    "SCOOTER", "MOTORCYCLE" -> Icons.Default.TwoWheeler
                                    "ECO" -> Icons.Default.ElectricCar
                                    "DELIVERY" -> Icons.Default.LocalShipping
                                    else -> Icons.Default.DirectionsCar
                                },
                                contentDescription = null,
                                tint = if (isSelected) LahzathaGreenDark else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = vCat.titleAr.replace("لحظتها ", ""),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) LahzathaGreenDark else MaterialTheme.colorScheme.onSurface,
                                maxLines = 1
                            )
                            Text(
                                text = "${vCat.etaMinutes} دقائق • ${vCat.seats} مقعد",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "$catFare ج.م",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = LahzathaGreenDark
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Payment & Promo Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Payment Method Selector
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.clickable {
                        val next = when (state.selectedPaymentType) {
                            PaymentType.WALLET -> PaymentType.CARD
                            PaymentType.CARD -> PaymentType.CASH
                            PaymentType.CASH -> PaymentType.WALLET
                        }
                        onSelectPayment(next)
                    }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = state.selectedPaymentType.icon,
                            contentDescription = null,
                            tint = LahzathaGreenDark,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = state.selectedPaymentType.titleAr,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // Promo code button
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = if (state.discountPercent > 0) LahzathaGreen.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.clickable { onOpenPromoDialog() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalOffer,
                            contentDescription = null,
                            tint = if (state.discountPercent > 0) LahzathaGreenDark else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (state.discountPercent > 0) "خصم ${state.discountPercent}%" else "كود خصم",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (state.discountPercent > 0) LahzathaGreenDark else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Big Book Ride CTA Button
            Button(
                onClick = onRequestRide,
                colors = ButtonDefaults.buttonColors(containerColor = LahzathaGreenDark),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("request_ride_button")
            ) {
                Text(
                    text = "طلب ${state.selectedCategory.titleAr} • ${currentFare.toInt()} ج.م",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun SearchingRadarSheet(
    secondsElapsed: Int,
    onCancel: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "radar")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "radarRotation"
    )

    Card(
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("searching_radar_sheet")
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier.size(90.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    modifier = Modifier
                        .fillMaxSize()
                        .rotate(rotation),
                    color = LahzathaGreenDark,
                    strokeWidth = 4.dp
                )
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(LahzathaGreen.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.NearMe,
                        contentDescription = null,
                        tint = LahzathaGreenDark,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "جارٍ الاتصال بأقرب كابتن...",
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "نبحث لك عن كابتن مميز بأعلى تقييم قريب من موقعك ($secondsElapsed ث)",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(20.dp))

            OutlinedButton(
                onClick = onCancel,
                colors = ButtonDefaults.outlinedButtonColors(contentColor = RedEmergency),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("cancel_search_button")
            ) {
                Text("إلغاء البحث عن كابتن", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun LiveTrackingSheet(
    ride: com.example.data.model.RideItem,
    onCancel: () -> Unit,
    onOpenSupportChat: () -> Unit,
    onOpenSos: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("live_tracking_sheet")
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            // Status Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = ride.status.titleAr,
                        fontWeight = FontWeight.Bold,
                        color = LahzathaGreenDark,
                        fontSize = 16.sp
                    )
                    Text(
                        text = "يصل خلال دقيقتين • مسار الرحلة مراقب",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row {
                    IconButton(
                        onClick = onOpenSupportChat,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Icon(Icons.Default.Chat, contentDescription = "محادثة", tint = LahzathaGreenDark)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = onOpenSos,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(RedEmergency.copy(alpha = 0.15f))
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = "SOS", tint = RedEmergency)
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Captain Profile Card
            ride.captain?.let { captain ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(50.dp)
                                    .clip(CircleShape)
                                    .background(LahzathaGreen.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = null,
                                    tint = LahzathaGreenDark,
                                    modifier = Modifier.size(32.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column {
                                Text(
                                    text = captain.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = null,
                                        tint = GoldRating,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${captain.rating} (${captain.totalRides} رحلة)",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                                Text(
                                    text = captain.carModel,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // Plate number badge
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color.White,
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, Color.Black)
                        ) {
                            Text(
                                text = captain.plateNumber,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = Color.Black,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Fare & Payment Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "الأجرة الإجمالية: ${ride.totalFare} ج.م (${ride.paymentType.titleAr})",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
                if (ride.status == RideStatus.CAPTAIN_ASSIGNED) {
                    OutlinedButton(
                        onClick = onCancel,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = RedEmergency)
                    ) {
                        Text("إلغاء الرحلة", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
