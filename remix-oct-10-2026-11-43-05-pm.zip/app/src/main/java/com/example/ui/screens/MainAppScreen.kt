package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.SyncAlt
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.AdminLoginDialog
import com.example.ui.components.PromoCodeDialog
import com.example.ui.components.RatingDialog
import com.example.ui.components.SosEmergencyDialog
import com.example.ui.components.TopUpDialog
import com.example.ui.theme.GoldRating
import com.example.ui.theme.LahzathaEmeraldDeep
import com.example.ui.theme.LahzathaGreen
import com.example.ui.theme.LahzathaGreenAccent
import com.example.ui.theme.LahzathaGreenDark
import com.example.ui.theme.RedEmergency
import com.example.ui.viewmodel.AppMode
import com.example.ui.viewmodel.LahzathaViewModel

enum class MainTab(val titleAr: String) {
    HOME("الرئيسية"),
    WALLET("المحفظة"),
    ACCOUNTING("لوحة التحكم"),
    SUPPORT("الدعم الفني")
}

@Composable
fun MainAppScreen(viewModel: LahzathaViewModel) {
    val state by viewModel.uiState.collectAsState()
    var currentTab by remember { mutableStateOf(MainTab.HOME) }
    var showSosDialog by remember { mutableStateOf(false) }
    var showPromoDialog by remember { mutableStateOf(false) }
    var showAdminLoginDialog by remember { mutableStateOf(false) }

    LaunchedEffect(state.isAdminAuthenticated) {
        if (!state.isAdminAuthenticated && currentTab == MainTab.ACCOUNTING) {
            currentTab = MainTab.HOME
        }
    }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(state.userNotification) {
        state.userNotification?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearNotification()
        }
    }

    BackHandler(enabled = currentTab != MainTab.HOME || state.currentMode != AppMode.PASSENGER) {
        if (currentTab != MainTab.HOME) {
            currentTab = MainTab.HOME
        } else if (state.currentMode != AppMode.PASSENGER) {
            viewModel.switchMode(AppMode.PASSENGER)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 4.dp,
                modifier = Modifier.statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    // App Logo & Name
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable {
                            currentTab = MainTab.HOME
                        }
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.lahzatha_official_logo_1791561563412),
                            contentDescription = "شعار لحظتها الرسمي",
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(8.dp))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "لحظتها",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp,
                                color = LahzathaGreenDark
                            )
                            Text(
                                text = "Careem-Class Ride",
                                fontSize = 9.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Mode Switcher Pill (Passenger ↔ Captain ↔ Accounting)
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .clickable {
                                when (state.currentMode) {
                                    AppMode.PASSENGER -> viewModel.switchMode(AppMode.CAPTAIN)
                                    AppMode.CAPTAIN -> {
                                        if (!state.isAdminAuthenticated) {
                                            showAdminLoginDialog = true
                                        } else {
                                            viewModel.switchMode(AppMode.ADMIN_ACCOUNTING)
                                        }
                                    }
                                    AppMode.ADMIN_ACCOUNTING -> viewModel.switchMode(AppMode.PASSENGER)
                                }
                            }
                            .testTag("mode_switcher_pill")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = when (state.currentMode) {
                                    AppMode.PASSENGER -> Icons.Default.Person
                                    AppMode.CAPTAIN -> Icons.Default.DirectionsCar
                                    AppMode.ADMIN_ACCOUNTING -> Icons.Default.AccountBalance
                                },
                                contentDescription = null,
                                tint = LahzathaGreenDark,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = state.currentMode.titleAr,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = LahzathaGreenDark
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.SyncAlt,
                                contentDescription = "تبديل",
                                tint = Color.Gray,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }

                    // Wallet quick balance badge & SOS
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = LahzathaGreen.copy(alpha = 0.12f),
                            modifier = Modifier.clickable { currentTab = MainTab.WALLET }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalanceWallet,
                                    contentDescription = null,
                                    tint = LahzathaGreenDark,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${state.userWalletBalance.toInt()} ج.م",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = LahzathaGreenDark
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(6.dp))

                        IconButton(
                            onClick = { showSosDialog = true },
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(RedEmergency.copy(alpha = 0.15f))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "طوارئ SOS",
                                tint = RedEmergency,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("main_bottom_nav")
            ) {
                // Tab 1: Home (Ride / Captain)
                NavigationBarItem(
                    selected = currentTab == MainTab.HOME,
                    onClick = { currentTab = MainTab.HOME },
                    icon = {
                        Icon(
                            imageVector = if (state.currentMode == AppMode.CAPTAIN) Icons.Default.DirectionsCar else Icons.Default.DirectionsCar,
                            contentDescription = "الرحلات"
                        )
                    },
                    label = { Text("الرحلات", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = LahzathaGreenDark,
                        selectedTextColor = LahzathaGreenDark,
                        indicatorColor = LahzathaGreen.copy(alpha = 0.2f)
                    ),
                    modifier = Modifier.testTag("tab_home")
                )

                // Tab 2: Wallet
                NavigationBarItem(
                    selected = currentTab == MainTab.WALLET,
                    onClick = { currentTab = MainTab.WALLET },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.AccountBalanceWallet,
                            contentDescription = "المحفظة"
                        )
                    },
                    label = { Text("المحفظة", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = LahzathaGreenDark,
                        selectedTextColor = LahzathaGreenDark,
                        indicatorColor = LahzathaGreen.copy(alpha = 0.2f)
                    ),
                    modifier = Modifier.testTag("tab_wallet")
                )

                // Tab 3: Accounting & App Profit (لوحة سحب الأرباح والعمولات)
                NavigationBarItem(
                    selected = currentTab == MainTab.ACCOUNTING,
                    onClick = {
                        if (!state.isAdminAuthenticated) {
                            showAdminLoginDialog = true
                        } else {
                            currentTab = MainTab.ACCOUNTING
                        }
                    },
                    icon = {
                        BadgedBox(badge = {
                            if (state.totalOutstandingDebt > 0) {
                                Badge(containerColor = RedEmergency) {
                                    Text("سحب")
                                }
                            }
                        }) {
                            Icon(
                                imageVector = Icons.Default.AccountBalance,
                                contentDescription = "لوحة التحكم"
                            )
                        }
                    },
                    label = { Text("لوحة التحكم", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = LahzathaGreenDark,
                        selectedTextColor = LahzathaGreenDark,
                        indicatorColor = LahzathaGreen.copy(alpha = 0.2f)
                    ),
                    modifier = Modifier.testTag("tab_accounting")
                )

                // Tab 4: 24/7 Support
                NavigationBarItem(
                    selected = currentTab == MainTab.SUPPORT,
                    onClick = { currentTab = MainTab.SUPPORT },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.HeadsetMic,
                            contentDescription = "الدعم"
                        )
                    },
                    label = { Text("الدعم 24/7", fontSize = 11.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = LahzathaGreenDark,
                        selectedTextColor = LahzathaGreenDark,
                        indicatorColor = LahzathaGreen.copy(alpha = 0.2f)
                    ),
                    modifier = Modifier.testTag("tab_support")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                MainTab.HOME -> {
                    when (state.currentMode) {
                        AppMode.PASSENGER -> {
                            PassengerScreen(
                                state = state,
                                popularDestinations = viewModel.popularDestinations,
                                currentFare = viewModel.calculateCurrentFare(),
                                onSelectDestination = viewModel::setDestination,
                                onSelectCategory = viewModel::setCategory,
                                onSelectVehicleCategory = viewModel::selectVehicleCategory,
                                onSelectPayment = viewModel::setPaymentType,
                                onOpenPromoDialog = {
                                    showPromoDialog = true
                                },
                                onRequestRide = viewModel::requestRide,
                                onCancelRide = viewModel::cancelRide,
                                onOpenSupportChat = { currentTab = MainTab.SUPPORT },
                                onOpenSos = { showSosDialog = true }
                            )
                        }
                        AppMode.CAPTAIN -> {
                            CaptainScreen(
                                state = state,
                                onToggleOnline = viewModel::toggleCaptainOnline,
                                onAcceptRide = viewModel::acceptCaptainRide,
                                onDeclineRide = viewModel::declineCaptainRide,
                                onAdvanceStep = viewModel::captainAdvanceStep,
                                onSettleDebt = viewModel::settleCaptainCommissionDebt,
                                onOpenSupportChat = { currentTab = MainTab.SUPPORT },
                                onOpenSos = { showSosDialog = true },
                                onSubmitDriverApplication = viewModel::submitDriverApplication
                            )
                        }
                        AppMode.ADMIN_ACCOUNTING -> {
                            AccountingDashboardScreen(
                                state = state,
                                onDeductCommission = viewModel::deductCommissionFromDriver,
                                onSettleAllCaptainDebts = viewModel::settleCaptainCommissionDebt,
                                onUpdateCommissionRate = viewModel::updateCommissionRate,
                                onUpdateMaxDebtLimit = viewModel::updateCaptainMaxDebtLimit,
                                onUpdateCategoryPricing = viewModel::updateCategoryPricing,
                                onResetPricing = viewModel::resetPricingToDefaults,
                                onAddNewPromoOffer = viewModel::addNewPromoOffer,
                                onDeletePromoOffer = viewModel::deletePromoOffer,
                                onTogglePromoOffer = viewModel::togglePromoOfferStatus,
                                onAddNewVehicleCategory = viewModel::addNewVehicleCategory,
                                onDeleteVehicleCategory = viewModel::deleteVehicleCategory,
                                onToggleVehicleCategory = viewModel::toggleVehicleCategoryStatus,
                                onUpdateVehicleCategoryDetails = viewModel::updateVehicleCategoryDetails,
                                onResetVehicleCategories = viewModel::resetVehicleCategoriesToDefault,
                                onSendGoldReward = viewModel::sendGoldRewardToCaptain,
                                onApproveDriverApplication = viewModel::approveDriverApplication,
                                onRejectDriverApplication = viewModel::rejectDriverApplication,
                                onLogoutAdmin = viewModel::logoutAdmin
                            )
                        }
                    }
                }
                MainTab.WALLET -> {
                    WalletScreen(
                        balance = state.userWalletBalance,
                        transactions = state.walletTransactions,
                        onOpenTopUp = { viewModel.topUpUserWallet(100.0) }
                    )
                }
                MainTab.ACCOUNTING -> {
                    AccountingDashboardScreen(
                        state = state,
                        onDeductCommission = viewModel::deductCommissionFromDriver,
                        onSettleAllCaptainDebts = viewModel::settleCaptainCommissionDebt,
                        onUpdateCommissionRate = viewModel::updateCommissionRate,
                        onUpdateMaxDebtLimit = viewModel::updateCaptainMaxDebtLimit,
                        onUpdateCategoryPricing = viewModel::updateCategoryPricing,
                        onResetPricing = viewModel::resetPricingToDefaults,
                        onAddNewPromoOffer = viewModel::addNewPromoOffer,
                        onDeletePromoOffer = viewModel::deletePromoOffer,
                        onTogglePromoOffer = viewModel::togglePromoOfferStatus,
                        onAddNewVehicleCategory = viewModel::addNewVehicleCategory,
                        onDeleteVehicleCategory = viewModel::deleteVehicleCategory,
                        onToggleVehicleCategory = viewModel::toggleVehicleCategoryStatus,
                        onUpdateVehicleCategoryDetails = viewModel::updateVehicleCategoryDetails,
                        onResetVehicleCategories = viewModel::resetVehicleCategoriesToDefault,
                        onSendGoldReward = viewModel::sendGoldRewardToCaptain,
                        onApproveDriverApplication = viewModel::approveDriverApplication,
                        onRejectDriverApplication = viewModel::rejectDriverApplication,
                        onLogoutAdmin = viewModel::logoutAdmin
                    )
                }
                MainTab.SUPPORT -> {
                    SupportScreen(
                        messages = state.chatMessages,
                        onSendMessage = viewModel::sendChatMessage,
                        onOpenSos = { showSosDialog = true }
                    )
                }
            }
        }
    }

    // Rating Dialog when passenger ride completes
    if (state.showRatingDialog) {
        RatingDialog(
            captainName = state.currentRide?.captain?.name ?: "كابتن أحمد",
            totalFare = state.currentRide?.totalFare ?: 75.0,
            onDismiss = { viewModel.submitRating(5, 0.0) },
            onSubmit = { stars, tip -> viewModel.submitRating(stars, tip) }
        )
    }

    // Promo Code Dialog
    if (showPromoDialog) {
        PromoCodeDialog(
            currentCode = state.promoCode,
            error = state.promoError,
            onDismiss = { showPromoDialog = false },
            onApply = { code ->
                viewModel.applyPromoCode(code)
                showPromoDialog = false
            }
        )
    }

    // Emergency SOS Dialog
    if (showSosDialog) {
        SosEmergencyDialog(onDismiss = { showSosDialog = false })
    }

    // Protected Admin Login Dialog
    if (showAdminLoginDialog) {
        AdminLoginDialog(
            initialEmail = "mahmoudomran324@gmail.com",
            errorMessage = state.adminAuthError,
            onDismiss = {
                showAdminLoginDialog = false
                viewModel.clearAdminAuthError()
            },
            onLogin = { email, password ->
                val success = viewModel.loginAdmin(email, password)
                if (success) {
                    showAdminLoginDialog = false
                    currentTab = MainTab.ACCOUNTING
                }
            }
        )
    }
}
