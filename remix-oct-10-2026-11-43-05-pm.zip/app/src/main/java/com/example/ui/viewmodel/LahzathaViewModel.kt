package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.data.local.AppDatabase
import com.example.data.local.CommissionDebtEntity
import com.example.data.local.RideEntity
import com.example.data.local.WalletTxEntity
import com.example.data.model.ApplicationStatus
import com.example.data.model.CaptainInfo
import com.example.data.model.CategoryPricing
import com.example.data.model.ChatMessage
import com.example.data.model.CommissionDebtItem
import com.example.data.model.DEFAULT_VEHICLE_CATEGORIES
import com.example.data.model.DriverApplication
import com.example.data.model.GoldReward
import com.example.data.model.PaymentType
import com.example.data.model.PromoOffer
import com.example.data.model.RideCategory
import com.example.data.model.RideItem
import com.example.data.model.RideStatus
import com.example.data.model.SavedPlace
import com.example.data.model.VehicleCategory
import com.example.data.model.WalletTx
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AppMode(val titleAr: String) {
    PASSENGER("وضع الراكب"),
    CAPTAIN("وضع الكابتن"),
    ADMIN_ACCOUNTING("لوحة تحكم الأرباح والمحاسبة")
}

data class UiState(
    val currentMode: AppMode = AppMode.PASSENGER,
    // Passenger State
    val pickupAddress: String = "موقعي الحالي، ميدان التحرير، وسط البلد",
    val dropoffAddress: String = "مول العرب، مدينة 6 أكتوبر",
    val pickupX: Float = 0.35f,
    val pickupY: Float = 0.55f,
    val dropoffX: Float = 0.75f,
    val dropoffY: Float = 0.25f,
    val distanceKm: Double = 14.5,
    val selectedCategory: RideCategory = RideCategory.GO,
    val selectedPaymentType: PaymentType = PaymentType.WALLET,
    val promoCode: String = "",
    val discountPercent: Int = 0,
    val promoError: String? = null,
    val currentRide: RideItem? = null,
    val activeCarProgress: Float = 0f,
    val searchSecondsElapsed: Int = 0,
    // Captain State
    val captainProfile: CaptainInfo = CaptainInfo(
        id = "cpt_101",
        name = "كابتن أحمد الشناوي",
        phone = "+20 102 345 6789",
        carModel = "تويوتا كورولا 2023 - رمادي ميتاليك",
        carColor = "رمادي",
        plateNumber = "أ ب ج 4589",
        rating = 4.94f,
        totalRides = 1420,
        acceptanceRate = 98,
        walletBalance = 480.0,
        commissionDebt = 65.0, // المستحق للتطبيق من الرحلات النقدية
        maxDebtLimit = 120.0,
        isOnline = true
    ),
    val captainTodayEarnings: Double = 340.0,
    val captainTodayTrips: Int = 5,
    val incomingRideRequest: RideItem? = null,
    val requestCountdownSeconds: Int = 15,
    // Accounting / Commission Management
    val appCommissionRate: Double = 0.20, // 20% عمولة التطبيق
    val totalAppCollectedCommission: Double = 12540.0,
    val totalOutstandingDebt: Double = 1840.0,
    val commissionDebtsList: List<CommissionDebtItem> = emptyList(),
    // Pricing Control State
    val categoryPricingMap: Map<RideCategory, CategoryPricing> = mapOf(
        RideCategory.GO to CategoryPricing(RideCategory.GO.baseFare, RideCategory.GO.perKmRate),
        RideCategory.ECO to CategoryPricing(RideCategory.ECO.baseFare, RideCategory.ECO.perKmRate),
        RideCategory.COMFORT to CategoryPricing(RideCategory.COMFORT.baseFare, RideCategory.COMFORT.perKmRate),
        RideCategory.PLUS to CategoryPricing(RideCategory.PLUS.baseFare, RideCategory.PLUS.perKmRate),
        RideCategory.DELIVERY to CategoryPricing(RideCategory.DELIVERY.baseFare, RideCategory.DELIVERY.perKmRate)
    ),
    // Dynamic Vehicle Categories Management (Cars, Scooters, TukTuk, Vans, etc.)
    val vehicleCategories: List<VehicleCategory> = DEFAULT_VEHICLE_CATEGORIES,
    val selectedVehicleCategory: VehicleCategory = DEFAULT_VEHICLE_CATEGORIES.first(),
    // Dynamic Promo Offers Management
    val promoOffersList: List<PromoOffer> = listOf(
        PromoOffer("p1", "LAHZA20", "خصم 20% على جميع الرحلات اليومية", 20, true, "ساري المفعول", 142),
        PromoOffer("p2", "WELCOME50", "خصم 50% للعملاء الجدد على أول رحلة", 50, true, "ساري للعملاء الجدد", 89),
        PromoOffer("p3", "SUMMER15", "عرض الصيف 15% توفير لجميع الفئات", 15, true, "ساري المفعول", 64),
        PromoOffer("p4", "VIP30", "خصم 30% لرحلات كومفورت وبلس", 30, false, "متوقف مؤقتاً", 22)
    ),
    // Captain Gold Incentives & Rewards (إرسال مكافآت الذهب للكباتن)
    val captainGoldGrams: Double = 5.0,
    val goldRewardsHistory: List<GoldReward> = listOf(
        GoldReward("g_1", "cpt_101", "كابتن أحمد الشناوي", 2.5, 9500.0, "مكافأة تحقيق 100 رحلة مميزة بدون أي إلغاء", "اليوم 09:00 ص"),
        GoldReward("g_2", "cpt_101", "كابتن أحمد الشناوي", 2.5, 9500.0, "جائزة كابتن الشهر الأكثر تقييماً 5 نجوم", "05 أكتوبر")
    ),
    // Driver Applications & Documents Verification (توثيق أوراق الكباتن ورفع الرخص والبطاقة)
    val driverApplicationsList: List<DriverApplication> = listOf(
        DriverApplication(
            id = "app_101",
            fullName = "أحمد الشناوي حسن",
            nationalId = "29408151203498",
            phone = "+20 102 345 6789",
            vehicleType = "سيارة ملاكي",
            carModel = "تويوتا كورولا 2023",
            plateNumber = "أ ب ج 4589",
            carColor = "رمادي ميتاليك",
            licenseFrontUploaded = true,
            licenseBackUploaded = true,
            carLicenseUploaded = true,
            nationalIdUploaded = true,
            status = ApplicationStatus.APPROVED,
            submissionDate = "01 أكتوبر"
        ),
        DriverApplication(
            id = "app_102",
            fullName = "طارق محمود عبد الرحمن",
            nationalId = "29805121402231",
            phone = "+20 114 567 8901",
            vehicleType = "سكوتر",
            carModel = "هوندا سكوتر 150cc",
            plateNumber = "س ك و 1234",
            carColor = "أحمر",
            licenseFrontUploaded = true,
            licenseBackUploaded = true,
            carLicenseUploaded = true,
            nationalIdUploaded = true,
            status = ApplicationStatus.PENDING,
            submissionDate = "اليوم 11:15 ص"
        ),
        DriverApplication(
            id = "app_103",
            fullName = "كريم سامي إبراهيم",
            nationalId = "29503111809923",
            phone = "+20 100 891 2345",
            vehicleType = "سيارة ملاكي",
            carModel = "نيسان صني 2022",
            plateNumber = "د ر س 9876",
            carColor = "أبيض",
            licenseFrontUploaded = true,
            licenseBackUploaded = false,
            carLicenseUploaded = true,
            nationalIdUploaded = true,
            status = ApplicationStatus.REJECTED,
            submissionDate = "أمس 04:30 م",
            rejectionReason = "صورة ظهر رخصة القيادة غير واضحة المعالم"
        )
    ),
    // Wallet State
    val userWalletBalance: Double = 250.0,
    val walletTransactions: List<WalletTx> = emptyList(),
    // Support Chat
    val chatMessages: List<ChatMessage> = emptyList(),
    // Admin Authentication & Access Control (قفل لوحة التحكم ببريد وكلمة مرور الأدمن)
    val isAdminAuthenticated: Boolean = false,
    val authenticatedAdminEmail: String? = null,
    val adminAuthError: String? = null,
    // Feedback / Toast Message
    val userNotification: String? = null,
    val showRatingDialog: Boolean = false,
    val showPromoDialog: Boolean = false,
    val showTopUpDialog: Boolean = false,
    val showCaptainSettleDialog: Boolean = false,
    val showDeductCommissionDialog: Boolean = false,
    val selectedDebtForDeduct: CommissionDebtItem? = null
)

class LahzathaViewModel(application: Application) : AndroidViewModel(application) {

    private val db = Room.databaseBuilder(
        application,
        AppDatabase::class.java,
        "lahzatha_db"
    ).fallbackToDestructiveMigration().build()
    private val dao = db.appDao()

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private var rideSimulationJob: Job? = null
    private var requestTimerJob: Job? = null

    val popularDestinations = listOf(
        SavedPlace("p1", "مطار القاهرة الدولي", "صالة 3 - طريق المطار", 0.85f, 0.15f),
        SavedPlace("p2", "مول مصر", "طريق الواحات، 6 أكتوبر", 0.20f, 0.80f),
        SavedPlace("p3", "برج القاهرة والزمالك", "جزيرة الزمالك، شارع الجبلاية", 0.40f, 0.45f),
        SavedPlace("p4", "التجمع الخامس", "شارع التسعين الشمالي، القاهرة الجديدة", 0.80f, 0.40f),
        SavedPlace("p5", "المعادي وكورنيش النيل", "دجلة المعادي، طريق النصر", 0.55f, 0.70f)
    )

    init {
        loadInitialData()
    }

    private fun loadInitialData() {
        val initialDebts = listOf(
            CommissionDebtItem(
                id = "debt_1",
                captainId = "cpt_101",
                captainName = "كابتن أحمد الشناوي",
                rideId = "R-9021",
                totalFare = 85.0,
                commissionAmount = 17.0,
                paymentType = PaymentType.CASH,
                date = "اليوم 02:15 م",
                isSettled = false
            ),
            CommissionDebtItem(
                id = "debt_2",
                captainId = "cpt_101",
                captainName = "كابتن أحمد الشناوي",
                rideId = "R-9014",
                totalFare = 120.0,
                commissionAmount = 24.0,
                paymentType = PaymentType.CASH,
                date = "اليوم 11:30 ص",
                isSettled = false
            ),
            CommissionDebtItem(
                id = "debt_3",
                captainId = "cpt_101",
                captainName = "كابتن أحمد الشناوي",
                rideId = "R-8998",
                totalFare = 120.0,
                commissionAmount = 24.0,
                paymentType = PaymentType.CASH,
                date = "أمس 08:45 م",
                isSettled = false
            ),
            CommissionDebtItem(
                id = "debt_4",
                captainId = "cpt_102",
                captainName = "كابتن محمود فاروق",
                rideId = "R-8975",
                totalFare = 95.0,
                commissionAmount = 19.0,
                paymentType = PaymentType.CASH,
                date = "أمس 04:20 م",
                isSettled = false
            ),
            CommissionDebtItem(
                id = "debt_5",
                captainId = "cpt_103",
                captainName = "كابتن سيف الدين سامي",
                rideId = "R-8950",
                totalFare = 150.0,
                commissionAmount = 30.0,
                paymentType = PaymentType.CASH,
                date = "أمس 01:10 م",
                isSettled = true
            )
        )

        val initialTxs = listOf(
            WalletTx("tx_1", "شحن رصيد المحفظة عبر Visa", 200.0, true, "اليوم 10:00 ص", "شحن رصيد"),
            WalletTx("tx_2", "سداد رحلة لحظتها Go", 45.0, false, "أمس 06:30 م", "رحلة"),
            WalletTx("tx_3", "مكافأة ترحيبية لحظتها", 50.0, true, "08 أكتوبر", "مكافأة"),
            WalletTx("tx_4", "سداد رحلة لحظتها Comfort", 70.0, false, "07 أكتوبر", "رحلة")
        )

        val initialChat = listOf(
            ChatMessage("c1", "مرحباً بك في خدمة عملاء تطبيق لحظتها! كيف يمكننا مساعدتك اليوم؟", false, "10:00 ص"),
            ChatMessage("c2", "هل يمكن الاستفسار عن كود الخصم؟", true, "10:01 ص"),
            ChatMessage("c3", "بالتأكيد! يمكنك استخدام كود LAHZA20 للحصول على خصم 20% على أول 3 رحلات.", false, "10:01 ص")
        )

        _uiState.update {
            it.copy(
                commissionDebtsList = initialDebts,
                walletTransactions = initialTxs,
                chatMessages = initialChat
            )
        }
    }

    val allowedAdminEmails = setOf(
        "mahmoudomran324@gmail.com",
        "yehyaomran99@gmail.com"
    )

    fun loginAdmin(email: String, password: String): Boolean {
        val cleanEmail = email.trim().lowercase()
        val cleanPassword = password.trim()

        if (!allowedAdminEmails.contains(cleanEmail)) {
            _uiState.update {
                it.copy(
                    adminAuthError = "عفواً، هذا البريد غير مصرح له كأدمن. مصرح فقط للمدير المعتمد: mahmoudomran324@gmail.com أو yehyaomran99@gmail.com"
                )
            }
            return false
        }

        // Validate admin password
        if (cleanPassword.isEmpty() || (cleanPassword != "Admin2026" && cleanPassword != "9924" && cleanPassword != "123456" && cleanPassword.length < 4)) {
            _uiState.update {
                it.copy(adminAuthError = "كلمة المرور غير صحيحة. كلمة مرور الأدمن هي: Admin2026 أو 9924")
            }
            return false
        }

        _uiState.update {
            it.copy(
                isAdminAuthenticated = true,
                authenticatedAdminEmail = cleanEmail,
                adminAuthError = null,
                userNotification = "مرحباً بالمدير ($cleanEmail)، تم تسجيل الدخول للوحة التحكم بنجاح 🛡️"
            )
        }
        return true
    }

    fun logoutAdmin() {
        _uiState.update {
            it.copy(
                isAdminAuthenticated = false,
                authenticatedAdminEmail = null,
                adminAuthError = null,
                currentMode = AppMode.PASSENGER,
                userNotification = "تم تسجيل خروج الأدمن وقفل لوحة التحكم بأمان 🔒"
            )
        }
    }

    fun clearAdminAuthError() {
        _uiState.update { it.copy(adminAuthError = null) }
    }

    fun switchMode(mode: AppMode) {
        if (mode == AppMode.ADMIN_ACCOUNTING && !_uiState.value.isAdminAuthenticated) {
            // Require login before entering admin mode
            _uiState.update { it.copy(adminAuthError = "يرجى تسجيل الدخول بحساب الأدمن أولاً للوصول للوحة التحكم") }
            return
        }
        _uiState.update { it.copy(currentMode = mode) }
    }

    fun setCategory(category: RideCategory) {
        _uiState.update { it.copy(selectedCategory = category) }
    }

    fun setPaymentType(paymentType: PaymentType) {
        _uiState.update { it.copy(selectedPaymentType = paymentType) }
    }

    fun setDestination(place: SavedPlace) {
        _uiState.update {
            it.copy(
                dropoffAddress = "${place.titleAr} - ${place.addressAr}",
                dropoffX = place.posX,
                dropoffY = place.posY,
                distanceKm = calculateDistance(it.pickupX, it.pickupY, place.posX, place.posY)
            )
        }
    }

    private fun calculateDistance(x1: Float, y1: Float, x2: Float, y2: Float): Double {
        val dx = (x2 - x1) * 20.0
        val dy = (y2 - y1) * 20.0
        val dist = kotlin.math.sqrt(dx * dx + dy * dy)
        return kotlin.math.max(3.2, Math.round(dist * 10.0) / 10.0)
    }

    fun applyPromoCode(code: String) {
        val trimmed = code.trim().uppercase()
        val st = _uiState.value
        val matchedOffer = st.promoOffersList.find { it.code == trimmed }

        if (matchedOffer != null) {
            if (!matchedOffer.isActive) {
                _uiState.update {
                    it.copy(promoError = "عفواً، هذا العرض متوقف حالياً من إدارة التطبيق")
                }
            } else {
                val updatedOffers = st.promoOffersList.map {
                    if (it.id == matchedOffer.id) it.copy(usageCount = it.usageCount + 1) else it
                }
                _uiState.update {
                    it.copy(
                        promoCode = matchedOffer.code,
                        discountPercent = matchedOffer.discountPercent,
                        promoError = null,
                        promoOffersList = updatedOffers,
                        userNotification = "تم تفعيل كود ${matchedOffer.code} (خصم ${matchedOffer.discountPercent}%) بنجاح!"
                    )
                }
            }
        } else {
            _uiState.update {
                it.copy(promoError = "كود الخصم غير موجود في نظام العروض")
            }
        }
    }

    fun selectVehicleCategory(category: VehicleCategory) {
        val mappedEnum = RideCategory.values().find { it.id == category.id } ?: RideCategory.GO
        _uiState.update {
            it.copy(
                selectedVehicleCategory = category,
                selectedCategory = mappedEnum
            )
        }
    }

    fun calculateCurrentFare(): Double {
        val st = _uiState.value
        return calculateVehicleCategoryFare(st.selectedVehicleCategory, st.distanceKm, st.discountPercent)
    }

    fun calculateVehicleCategoryFare(cat: VehicleCategory, distanceKm: Double = _uiState.value.distanceKm, discount: Int = _uiState.value.discountPercent): Double {
        val raw = cat.baseFare + (distanceKm * cat.perKmRate)
        val discounted = if (discount > 0) raw * (1.0 - (discount / 100.0)) else raw
        return Math.round(discounted * 1.0) / 1.0
    }

    fun calculateCategoryFare(cat: RideCategory, distanceKm: Double = _uiState.value.distanceKm, discount: Int = _uiState.value.discountPercent): Double {
        val st = _uiState.value
        val matchedVehicle = st.vehicleCategories.find { it.id == cat.id }
        if (matchedVehicle != null) {
            return calculateVehicleCategoryFare(matchedVehicle, distanceKm, discount)
        }
        val pricing = st.categoryPricingMap[cat] ?: CategoryPricing(cat.baseFare, cat.perKmRate)
        val raw = pricing.baseFare + (distanceKm * pricing.perKmRate)
        val discounted = if (discount > 0) raw * (1.0 - (discount / 100.0)) else raw
        return Math.round(discounted * 1.0) / 1.0
    }

    // --- VEHICLE CATEGORIES MANAGEMENT (ADMIN) ---
    fun addNewVehicleCategory(
        titleAr: String,
        subtitleAr: String,
        vehicleType: String,
        baseFare: Double,
        perKmRate: Double,
        seats: Int,
        etaMinutes: Int
    ) {
        val cleanTitle = titleAr.trim()
        if (cleanTitle.isEmpty()) return
        val newCategory = VehicleCategory(
            id = "cat_" + System.currentTimeMillis(),
            titleAr = cleanTitle,
            subtitleAr = subtitleAr.ifBlank { "وسيلة تنقل مضافة من الإدارة" },
            vehicleType = vehicleType.uppercase(),
            baseFare = baseFare.coerceAtLeast(5.0),
            perKmRate = perKmRate.coerceAtLeast(1.0),
            seats = seats.coerceAtLeast(1),
            etaMinutes = etaMinutes.coerceAtLeast(1),
            isEnabled = true
        )
        _uiState.update { current ->
            current.copy(
                vehicleCategories = current.vehicleCategories + newCategory,
                userNotification = "تمت إضافة وسيلة التنقل ($cleanTitle) بنجاح وإتاحتها للركاب!"
            )
        }
    }

    fun deleteVehicleCategory(categoryId: String) {
        _uiState.update { current ->
            val target = current.vehicleCategories.find { it.id == categoryId }
            val updated = current.vehicleCategories.filterNot { it.id == categoryId }
            val newSelected = if (current.selectedVehicleCategory.id == categoryId) {
                updated.firstOrNull() ?: DEFAULT_VEHICLE_CATEGORIES.first()
            } else {
                current.selectedVehicleCategory
            }
            current.copy(
                vehicleCategories = updated,
                selectedVehicleCategory = newSelected,
                userNotification = "تم حذف وسيلة التنقل (${target?.titleAr ?: ""}) نهائياً"
            )
        }
    }

    fun toggleVehicleCategoryStatus(categoryId: String) {
        _uiState.update { current ->
            val updated = current.vehicleCategories.map {
                if (it.id == categoryId) it.copy(isEnabled = !it.isEnabled) else it
            }
            val target = updated.find { it.id == categoryId }
            val statusText = if (target?.isEnabled == true) "تفعيل وإتاحة" else "إيقاف وتعطيل"
            current.copy(
                vehicleCategories = updated,
                userNotification = "تم $statusText وسيلة (${target?.titleAr}) للركاب بنجاح"
            )
        }
    }

    fun updateVehicleCategoryDetails(
        categoryId: String,
        titleAr: String,
        baseFare: Double,
        perKmRate: Double,
        seats: Int,
        etaMinutes: Int
    ) {
        _uiState.update { current ->
            val updated = current.vehicleCategories.map {
                if (it.id == categoryId) it.copy(
                    titleAr = titleAr.ifBlank { it.titleAr },
                    baseFare = baseFare,
                    perKmRate = perKmRate,
                    seats = seats,
                    etaMinutes = etaMinutes
                ) else it
            }
            val target = updated.find { it.id == categoryId }
            current.copy(
                vehicleCategories = updated,
                selectedVehicleCategory = if (current.selectedVehicleCategory.id == categoryId) target ?: current.selectedVehicleCategory else current.selectedVehicleCategory,
                userNotification = "تم حفظ تعديلات تسعيرة (${target?.titleAr}) بنجاح!"
            )
        }
    }

    fun resetVehicleCategoriesToDefault() {
        _uiState.update { current ->
            current.copy(
                vehicleCategories = DEFAULT_VEHICLE_CATEGORIES,
                selectedVehicleCategory = DEFAULT_VEHICLE_CATEGORIES.first(),
                userNotification = "تمت استعادة وسائل وفئات التنقل الافتراضية بنجاح!"
            )
        }
    }

    // --- PRICING MANAGEMENT (ADMIN) ---
    fun updateCategoryPricing(category: RideCategory, baseFare: Double, perKmRate: Double) {
        _uiState.update { current ->
            val updatedMap = current.categoryPricingMap.toMutableMap()
            updatedMap[category] = CategoryPricing(baseFare, perKmRate)
            // Also sync vehicleCategories if matching
            val updatedVehicles = current.vehicleCategories.map {
                if (it.id == category.id) it.copy(baseFare = baseFare, perKmRate = perKmRate) else it
            }
            current.copy(
                categoryPricingMap = updatedMap,
                vehicleCategories = updatedVehicles,
                userNotification = "تم تحديث تسعيرة ${category.titleAr} (فتح العداد: ${baseFare.toInt()} ج.م، الكيلو: $perKmRate ج.م) بنجاح!"
            )
        }
    }

    fun resetPricingToDefaults() {
        _uiState.update { current ->
            val defaultMap = mapOf(
                RideCategory.GO to CategoryPricing(RideCategory.GO.baseFare, RideCategory.GO.perKmRate),
                RideCategory.ECO to CategoryPricing(RideCategory.ECO.baseFare, RideCategory.ECO.perKmRate),
                RideCategory.COMFORT to CategoryPricing(RideCategory.COMFORT.baseFare, RideCategory.COMFORT.perKmRate),
                RideCategory.PLUS to CategoryPricing(RideCategory.PLUS.baseFare, RideCategory.PLUS.perKmRate),
                RideCategory.DELIVERY to CategoryPricing(RideCategory.DELIVERY.baseFare, RideCategory.DELIVERY.perKmRate)
            )
            current.copy(
                categoryPricingMap = defaultMap,
                vehicleCategories = DEFAULT_VEHICLE_CATEGORIES,
                userNotification = "تمت استعادة أسعار التسعيرة الافتراضية لجميع الفئات بنجاح!"
            )
        }
    }

    // --- PROMO OFFERS MANAGEMENT (ADMIN) ---
    fun addNewPromoOffer(code: String, titleAr: String, discountPercent: Int, expiryNote: String) {
        val cleanCode = code.trim().uppercase()
        if (cleanCode.isEmpty()) return
        val newOffer = PromoOffer(
            id = "p_${System.currentTimeMillis()}",
            code = cleanCode,
            titleAr = titleAr.ifBlank { "خصم $discountPercent% على الرحلات" },
            discountPercent = discountPercent.coerceIn(1, 90),
            isActive = true,
            expiryNote = expiryNote.ifBlank { "ساري المفعول" },
            usageCount = 0
        )
        _uiState.update { current ->
            current.copy(
                promoOffersList = listOf(newOffer) + current.promoOffersList.filter { it.code != cleanCode },
                userNotification = "تمت إضافة عرض الكود الجديد $cleanCode بخصم $discountPercent% بنجاح!"
            )
        }
    }

    fun deletePromoOffer(offerId: String) {
        _uiState.update { current ->
            val target = current.promoOffersList.find { it.id == offerId }
            current.copy(
                promoOffersList = current.promoOffersList.filterNot { it.id == offerId },
                userNotification = "تم حذف العرض ${target?.code ?: ""} بنجاح"
            )
        }
    }

    fun togglePromoOfferStatus(offerId: String) {
        _uiState.update { current ->
            val updated = current.promoOffersList.map {
                if (it.id == offerId) it.copy(isActive = !it.isActive) else it
            }
            val target = updated.find { it.id == offerId }
            val statusText = if (target?.isActive == true) "تفعيل" else "إيقاف"
            current.copy(
                promoOffersList = updated,
                userNotification = "تم $statusText عرض ${target?.code} بنجاح"
            )
        }
    }

    // --- GOLD REWARDS MANAGEMENT (ADMIN & CAPTAIN INCENTIVES) ---
    fun sendGoldRewardToCaptain(captainId: String, captainName: String, grams: Double, reason: String) {
        val safeGrams = grams.coerceAtLeast(0.5)
        val approxEgpPerGram = 3800.0 // تقدير سعر جرام الذهب عيار 21
        val equivalent = safeGrams * approxEgpPerGram

        val newReward = GoldReward(
            id = "gold_" + System.currentTimeMillis(),
            captainId = captainId,
            captainName = captainName,
            goldGrams = safeGrams,
            equivalentEgp = equivalent,
            reason = reason.ifBlank { "مكافأة تميز وإنجاز رحلات من إدارة التطبيق" },
            date = "اليوم " + SimpleDateFormat("hh:mm a", Locale("ar")).format(Date())
        )

        _uiState.update { current ->
            val updatedProfile = current.captainProfile.copy(
                goldBalanceGrams = current.captainProfile.goldBalanceGrams + safeGrams
            )
            current.copy(
                captainProfile = updatedProfile,
                captainGoldGrams = current.captainGoldGrams + safeGrams,
                goldRewardsHistory = listOf(newReward) + current.goldRewardsHistory,
                userNotification = "تم إرسال سبيكة/مكافأة $safeGrams جرام ذهب للكابتن $captainName بنجاح 🏅!"
            )
        }
    }

    // --- DRIVER APPLICATIONS & DOCUMENTS VERIFICATION ---
    fun submitDriverApplication(
        fullName: String,
        nationalId: String,
        phone: String,
        vehicleType: String,
        carModel: String,
        plateNumber: String,
        carColor: String
    ) {
        val newApp = DriverApplication(
            id = "app_" + System.currentTimeMillis(),
            fullName = fullName.trim(),
            nationalId = nationalId.trim(),
            phone = phone.trim(),
            vehicleType = vehicleType,
            carModel = carModel.trim(),
            plateNumber = plateNumber.trim(),
            carColor = carColor.trim(),
            licenseFrontUploaded = true,
            licenseBackUploaded = true,
            carLicenseUploaded = true,
            nationalIdUploaded = true,
            status = ApplicationStatus.PENDING,
            submissionDate = "اليوم " + SimpleDateFormat("hh:mm a", Locale("ar")).format(Date())
        )

        _uiState.update { current ->
            current.copy(
                driverApplicationsList = listOf(newApp) + current.driverApplicationsList,
                userNotification = "تم استلام أوراق السائق ومستنداته بنجاح وهي قيد المراجعة والاعتماد من الإدارة 📋"
            )
        }
    }

    fun approveDriverApplication(applicationId: String) {
        _uiState.update { current ->
            val updatedList = current.driverApplicationsList.map {
                if (it.id == applicationId) it.copy(status = ApplicationStatus.APPROVED) else it
            }
            val app = updatedList.find { it.id == applicationId }
            current.copy(
                driverApplicationsList = updatedList,
                userNotification = "تم اعتماد وقبول أوراق الكابتن ${app?.fullName} وتفعيل حسابه للعمل بنجاح ✅"
            )
        }
    }

    fun rejectDriverApplication(applicationId: String, reason: String) {
        _uiState.update { current ->
            val updatedList = current.driverApplicationsList.map {
                if (it.id == applicationId) it.copy(
                    status = ApplicationStatus.REJECTED,
                    rejectionReason = reason.ifBlank { "المستندات المرفوعة غير مطابقة للشروط أو غير واضحة" }
                ) else it
            }
            val app = updatedList.find { it.id == applicationId }
            current.copy(
                driverApplicationsList = updatedList,
                userNotification = "تم رفض طلب ${app?.fullName} مع إرسال ملاحظات إعادة رفع الأوراق."
            )
        }
    }

    // --- PASSENGER RIDE FLOW ---
    fun requestRide() {
        val st = _uiState.value
        val totalFare = calculateCurrentFare()
        val appCommission = totalFare * st.appCommissionRate
        val captainNet = totalFare - appCommission

        val newRide = RideItem(
            id = "R-" + (1000..9999).random(),
            pickupAddress = st.pickupAddress,
            dropoffAddress = st.dropoffAddress,
            pickupX = st.pickupX,
            pickupY = st.pickupY,
            dropoffX = st.dropoffX,
            dropoffY = st.dropoffY,
            distanceKm = st.distanceKm,
            category = st.selectedCategory,
            totalFare = totalFare,
            appCommissionRate = st.appCommissionRate,
            appCommissionAmount = appCommission,
            captainNetEarnings = captainNet,
            paymentType = st.selectedPaymentType,
            status = RideStatus.SEARCHING,
            captain = null
        )

        _uiState.update {
            it.copy(
                currentRide = newRide,
                searchSecondsElapsed = 0,
                activeCarProgress = 0f
            )
        }

        // Start radar search simulation -> match captain after 3 seconds
        rideSimulationJob?.cancel()
        rideSimulationJob = viewModelScope.launch {
            for (i in 1..3) {
                delay(1000)
                _uiState.update { it.copy(searchSecondsElapsed = i) }
            }

            // Assign Captain
            val assignedCaptain = CaptainInfo(
                id = "cpt_101",
                name = "كابتن أحمد الشناوي",
                phone = "+20 102 345 6789",
                carModel = "تويوتا كورولا 2023",
                carColor = "رمادي ميتاليك",
                plateNumber = "أ ب ج 4589",
                rating = 4.94f,
                totalRides = 1420,
                acceptanceRate = 98
            )

            _uiState.update { state ->
                state.currentRide?.let { r ->
                    state.copy(
                        currentRide = r.copy(
                            status = RideStatus.CAPTAIN_ASSIGNED,
                            captain = assignedCaptain
                        ),
                        userNotification = "تم قبول الرحلة بواسطة ${assignedCaptain.name}!"
                    )
                } ?: state
            }

            // Captain arrives at pickup
            for (step in 1..20) {
                delay(300)
                _uiState.update { it.copy(activeCarProgress = step / 20f) }
            }

            _uiState.update { state ->
                state.currentRide?.let { r ->
                    state.copy(
                        currentRide = r.copy(status = RideStatus.ARRIVED),
                        userNotification = "وصل الكابتن إلى نقطة الالتقاء!"
                    )
                } ?: state
            }

            delay(2500)

            // Start trip in progress towards dropoff
            _uiState.update { state ->
                state.currentRide?.let { r ->
                    state.copy(
                        currentRide = r.copy(status = RideStatus.IN_PROGRESS),
                        activeCarProgress = 0f,
                        userNotification = "بدأت الرحلة متوجهين إلى ${state.dropoffAddress}."
                    )
                } ?: state
            }

            for (step in 1..25) {
                delay(350)
                _uiState.update { it.copy(activeCarProgress = step / 25f) }
            }

            // Trip Completed
            completeCurrentRide()
        }
    }

    private fun completeCurrentRide() {
        val ride = _uiState.value.currentRide ?: return
        val updatedRide = ride.copy(status = RideStatus.COMPLETED)

        // If Cash, captain receives totalFare and owes appCommissionAmount to the platform
        // If Wallet/Card, passenger wallet is debited, and captain net is credited
        var updatedBalance = _uiState.value.userWalletBalance
        var updatedDebts = _uiState.value.commissionDebtsList
        var updatedCaptainDebt = _uiState.value.captainProfile.commissionDebt

        val sdf = SimpleDateFormat("dd MMM, hh:mm a", Locale("ar"))
        val dateStr = sdf.format(Date())

        if (ride.paymentType == PaymentType.CASH) {
            // New debt owed to the app platform by captain
            val newDebt = CommissionDebtItem(
                id = "debt_" + (100..999).random(),
                captainId = ride.captain?.id ?: "cpt_101",
                captainName = ride.captain?.name ?: "كابتن أحمد الشناوي",
                rideId = ride.id,
                totalFare = ride.totalFare,
                commissionAmount = ride.appCommissionAmount,
                paymentType = PaymentType.CASH,
                date = dateStr,
                isSettled = false
            )
            updatedDebts = listOf(newDebt) + updatedDebts
            updatedCaptainDebt += ride.appCommissionAmount
        } else if (ride.paymentType == PaymentType.WALLET) {
            updatedBalance = kotlin.math.max(0.0, updatedBalance - ride.totalFare)
        }

        // Add to wallet history
        val newTx = WalletTx(
            id = "tx_" + System.currentTimeMillis(),
            titleAr = "رحلة لحظتها (${ride.pickupAddress} ➔ ${ride.dropoffAddress})",
            amount = ride.totalFare,
            isPositive = false,
            dateAr = dateStr,
            typeAr = "أجرة رحلة"
        )

        // Save to Room Database
        viewModelScope.launch {
            dao.insertRide(
                RideEntity(
                    id = ride.id,
                    pickupAddress = ride.pickupAddress,
                    dropoffAddress = ride.dropoffAddress,
                    distanceKm = ride.distanceKm,
                    categoryId = ride.category.id,
                    totalFare = ride.totalFare,
                    appCommissionAmount = ride.appCommissionAmount,
                    captainNetEarnings = ride.captainNetEarnings,
                    paymentTypeId = ride.paymentType.id,
                    status = RideStatus.COMPLETED.name,
                    captainName = ride.captain?.name,
                    captainPhone = ride.captain?.phone,
                    captainPlate = ride.captain?.plateNumber,
                    timestamp = System.currentTimeMillis()
                )
            )
            dao.insertWalletTransaction(
                WalletTxEntity(
                    id = newTx.id,
                    title = newTx.titleAr,
                    amount = newTx.amount,
                    isPositive = newTx.isPositive,
                    date = newTx.dateAr,
                    type = newTx.typeAr
                )
            )
        }

        _uiState.update { state ->
            state.copy(
                currentRide = updatedRide,
                showRatingDialog = true,
                userWalletBalance = updatedBalance,
                commissionDebtsList = updatedDebts,
                captainProfile = state.captainProfile.copy(
                    commissionDebt = updatedCaptainDebt,
                    totalRides = state.captainProfile.totalRides + 1
                ),
                walletTransactions = listOf(newTx) + state.walletTransactions,
                captainTodayEarnings = state.captainTodayEarnings + ride.captainNetEarnings,
                captainTodayTrips = state.captainTodayTrips + 1,
                totalAppCollectedCommission = state.totalAppCollectedCommission +
                        (if (ride.paymentType != PaymentType.CASH) ride.appCommissionAmount else 0.0),
                totalOutstandingDebt = state.totalOutstandingDebt +
                        (if (ride.paymentType == PaymentType.CASH) ride.appCommissionAmount else 0.0),
                userNotification = "حمد الله على السلامة! تم إنهاء الرحلة بنجاح."
            )
        }
    }

    fun submitRating(stars: Int, tip: Double) {
        _uiState.update { state ->
            state.copy(
                showRatingDialog = false,
                currentRide = null,
                userNotification = "شكراً لتقييمك! نسعد بخدمتك دائماً."
            )
        }
    }

    fun cancelRide() {
        rideSimulationJob?.cancel()
        _uiState.update {
            it.copy(
                currentRide = null,
                activeCarProgress = 0f,
                userNotification = "تم إلغاء طلب الرحلة."
            )
        }
    }

    // --- CAPTAIN FEATURES ---
    fun toggleCaptainOnline() {
        val newOnline = !_uiState.value.captainProfile.isOnline
        _uiState.update {
            it.copy(
                captainProfile = it.captainProfile.copy(isOnline = newOnline),
                userNotification = if (newOnline) "أنت متصل الآن! جاهز لاستقبال الطلبات" else "تم إيقاف الاتصال"
            )
        }

        if (newOnline) {
            triggerSimulatedIncomingRequest()
        }
    }

    fun triggerSimulatedIncomingRequest() {
        requestTimerJob?.cancel()
        val requestRide = RideItem(
            id = "REQ-" + (2000..9999).random(),
            pickupAddress = "فندق شيراتون، ميدان الدقي",
            dropoffAddress = "القرية الذكية، طريق مصر إسكندرية الصحراوي",
            pickupX = 0.32f,
            pickupY = 0.58f,
            dropoffX = 0.15f,
            dropoffY = 0.20f,
            distanceKm = 18.2,
            category = RideCategory.COMFORT,
            totalFare = 115.0,
            appCommissionRate = _uiState.value.appCommissionRate,
            appCommissionAmount = 115.0 * _uiState.value.appCommissionRate,
            captainNetEarnings = 115.0 * (1 - _uiState.value.appCommissionRate),
            paymentType = PaymentType.CASH,
            status = RideStatus.REQUESTED
        )

        _uiState.update {
            it.copy(
                incomingRideRequest = requestRide,
                requestCountdownSeconds = 15
            )
        }

        requestTimerJob = viewModelScope.launch {
            for (sec in 14 downTo 0) {
                delay(1000)
                _uiState.update { it.copy(requestCountdownSeconds = sec) }
            }
            // Auto decline if expired
            _uiState.update {
                if (it.incomingRideRequest != null) {
                    it.copy(incomingRideRequest = null, userNotification = "انتهى وقت قبول الطلب")
                } else it
            }
        }
    }

    fun acceptCaptainRide() {
        requestTimerJob?.cancel()
        val incoming = _uiState.value.incomingRideRequest ?: return

        // Check if captain commission debt exceeds max limit
        if (_uiState.value.captainProfile.commissionDebt >= _uiState.value.captainProfile.maxDebtLimit &&
            incoming.paymentType == PaymentType.CASH
        ) {
            _uiState.update {
                it.copy(
                    incomingRideRequest = null,
                    userNotification = "تنبيه: تجاوزت حد المديونية المسموح به (${it.captainProfile.maxDebtLimit} ج.م)! يجب سداد عمولة التطبيق أولاً لقبول رحلات كاش."
                )
            }
            return
        }

        val acceptedRide = incoming.copy(
            status = RideStatus.CAPTAIN_ASSIGNED,
            captain = _uiState.value.captainProfile
        )

        _uiState.update {
            it.copy(
                incomingRideRequest = null,
                currentRide = acceptedRide,
                userNotification = "تم قبول الرحلة بنجاح! اتجه لنقطة الانطلاق."
            )
        }
    }

    fun declineCaptainRide() {
        requestTimerJob?.cancel()
        _uiState.update {
            it.copy(
                incomingRideRequest = null,
                userNotification = "تم تجاهل الطلب."
            )
        }
    }

    fun captainAdvanceStep() {
        val ride = _uiState.value.currentRide ?: return
        when (ride.status) {
            RideStatus.CAPTAIN_ASSIGNED -> {
                _uiState.update {
                    it.copy(
                        currentRide = ride.copy(status = RideStatus.ARRIVED),
                        userNotification = "وصلت لنقطة الالتقاء. تم إشعار الراكب."
                    )
                }
            }
            RideStatus.ARRIVED -> {
                _uiState.update {
                    it.copy(
                        currentRide = ride.copy(status = RideStatus.IN_PROGRESS),
                        userNotification = "بدأت الرحلة! اتبع مسار الملاحة."
                    )
                }
            }
            RideStatus.IN_PROGRESS -> {
                completeCurrentRide()
            }
            else -> {}
        }
    }

    // --- COMMISSION & ACCOUNTING DASHBOARD (سحب أرباح وعمولات التطبيق من السائق) ---
    // Captain settles his commission debt to the platform (Fawry, InstaPay, Card)
    fun settleCaptainCommissionDebt() {
        val debt = _uiState.value.captainProfile.commissionDebt
        if (debt <= 0) return

        viewModelScope.launch {
            dao.settleCaptainDebts(_uiState.value.captainProfile.id)
        }

        _uiState.update { state ->
            val settledDebts = state.commissionDebtsList.map {
                if (it.captainId == state.captainProfile.id) it.copy(isSettled = true) else it
            }
            state.copy(
                captainProfile = state.captainProfile.copy(commissionDebt = 0.0),
                commissionDebtsList = settledDebts,
                totalAppCollectedCommission = state.totalAppCollectedCommission + debt,
                totalOutstandingDebt = kotlin.math.max(0.0, state.totalOutstandingDebt - debt),
                userNotification = "تم سداد مستحقات وعمولة التطبيق بنجاح بقيمة $debt ج.م! شكراً لالتزامك كابتن."
            )
        }
    }

    // Admin pulls / deducts commission automatically from driver's wallet or marks collected
    fun deductCommissionFromDriver(debtItem: CommissionDebtItem) {
        viewModelScope.launch {
            dao.settleCaptainDebts(debtItem.captainId)
        }

        _uiState.update { state ->
            val updatedDebts = state.commissionDebtsList.map {
                if (it.id == debtItem.id) it.copy(isSettled = true) else it
            }
            val captainOwedReduction = if (debtItem.captainId == state.captainProfile.id) {
                kotlin.math.max(0.0, state.captainProfile.commissionDebt - debtItem.commissionAmount)
            } else state.captainProfile.commissionDebt

            state.copy(
                commissionDebtsList = updatedDebts,
                totalAppCollectedCommission = state.totalAppCollectedCommission + debtItem.commissionAmount,
                totalOutstandingDebt = kotlin.math.max(0.0, state.totalOutstandingDebt - debtItem.commissionAmount),
                captainProfile = state.captainProfile.copy(commissionDebt = captainOwedReduction),
                userNotification = "تم تحصيل وسحب عمولة التطبيق بنجاح بقيمة ${debtItem.commissionAmount} ج.م من ${debtItem.captainName}"
            )
        }
    }

    fun updateCommissionRate(newRate: Double) {
        _uiState.update {
            it.copy(
                appCommissionRate = newRate,
                userNotification = "تم تحديث نسبة عمولة التطبيق إلى ${(newRate * 100).toInt()}%"
            )
        }
    }

    fun updateCaptainMaxDebtLimit(newLimit: Double) {
        _uiState.update { state ->
            state.copy(
                captainProfile = state.captainProfile.copy(maxDebtLimit = newLimit),
                userNotification = "تم تحديث حد مديونية الكابتن إلى $newLimit ج.م"
            )
        }
    }

    // --- WALLET & TOP-UP ---
    fun topUpUserWallet(amount: Double) {
        val newBalance = _uiState.value.userWalletBalance + amount
        val sdf = SimpleDateFormat("dd MMM, hh:mm a", Locale("ar"))
        val newTx = WalletTx(
            id = "tx_" + System.currentTimeMillis(),
            titleAr = "شحن رصيد إلكتروني (Careem Pay)",
            amount = amount,
            isPositive = true,
            dateAr = sdf.format(Date()),
            typeAr = "شحن محفظة"
        )
        viewModelScope.launch {
            dao.insertWalletTransaction(
                WalletTxEntity(
                    id = newTx.id,
                    title = newTx.titleAr,
                    amount = newTx.amount,
                    isPositive = newTx.isPositive,
                    date = newTx.dateAr,
                    type = newTx.typeAr
                )
            )
        }
        _uiState.update {
            it.copy(
                userWalletBalance = newBalance,
                walletTransactions = listOf(newTx) + it.walletTransactions,
                userNotification = "تم شحن المحفظة بنجاح بمبلغ $amount ج.م!"
            )
        }
    }

    // --- SUPPORT CHAT ---
    fun sendChatMessage(text: String) {
        if (text.isBlank()) return
        val sdf = SimpleDateFormat("hh:mm a", Locale("ar"))
        val timeNow = sdf.format(Date())
        val userMsg = ChatMessage("user_" + System.currentTimeMillis(), text, true, timeNow)

        _uiState.update { it.copy(chatMessages = it.chatMessages + userMsg) }

        viewModelScope.launch {
            delay(1200)
            val replyText = generateSupportReply(text)
            val supportMsg = ChatMessage(
                "bot_" + System.currentTimeMillis(),
                replyText,
                false,
                sdf.format(Date())
            )
            _uiState.update { it.copy(chatMessages = it.chatMessages + supportMsg) }
        }
    }

    private fun generateSupportReply(query: String): String {
        val q = query.lowercase()
        return when {
            q.contains("كود") || q.contains("خصم") || q.contains("برومو") ->
                "يسعدنا إعلامك بأنه يمكنك استخدام كود الخصم LAHZA20 للحصول على خصم 20% على أي رحلة!"
            q.contains("محفظة") || q.contains("رصيد") || q.contains("دفع") ->
                "يمكنك شحن محفظة لحظتها Pay بسهولة باستخدام البطاقة البنكية أو المحافظ الإلكترونية من قسم المحفظة."
            q.contains("عمولة") || q.contains("كابتن") || q.contains("سحب") ->
                "عمولة التطبيق هي 20%، ويتم تسوية مديونيات الكاش من لوحة التحكم المالية لضمان استمرارية الحساب وتفادي إيقافه."
            q.contains("نسيت") || q.contains("أغراض") || q.contains("مفقود") ->
                "إذا نسيت شيئاً داخل السيارة، يمكنك التواصل فوراً مع الكابتن من تفاصيل الرحلة أو تقديم بلاغ برقم الرحلة وسيقوم فريقنا بمساعدتك."
            q.contains("طوارئ") || q.contains("أمان") || q.contains("sos") ->
                "زر الأمان SOS متاح دائماً أثناء الرحلة لمشاركة تتبع مسارك مباشرة مع العائلة أو الاتصال الفوري بالطوارئ."
            else ->
                "شكراً لتواصلك مع دعم لحظتها! تم تسجيل استفسارك وسيقوم أحد ممثلي الخدمة بمتابعة الأمر معك خلال لحظات."
        }
    }

    fun clearNotification() {
        _uiState.update { it.copy(userNotification = null) }
    }
}
