package com.example.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "rides")
data class RideEntity(
    @PrimaryKey val id: String,
    val pickupAddress: String,
    val dropoffAddress: String,
    val distanceKm: Double,
    val categoryId: String,
    val totalFare: Double,
    val appCommissionAmount: Double,
    val captainNetEarnings: Double,
    val paymentTypeId: String,
    val status: String,
    val captainName: String?,
    val captainPhone: String?,
    val captainPlate: String?,
    val timestamp: Long,
    val rating: Int = 0,
    val tip: Double = 0.0
)

@Entity(tableName = "commission_debts")
data class CommissionDebtEntity(
    @PrimaryKey val id: String,
    val captainId: String,
    val captainName: String,
    val rideId: String,
    val totalFare: Double,
    val commissionAmount: Double,
    val paymentTypeId: String,
    val date: String,
    val isSettled: Boolean
)

@Entity(tableName = "wallet_transactions")
data class WalletTxEntity(
    @PrimaryKey val id: String,
    val title: String,
    val amount: Double,
    val isPositive: Boolean,
    val date: String,
    val type: String
)

@Entity(tableName = "captain_profile")
data class CaptainProfileEntity(
    @PrimaryKey val id: String,
    val name: String,
    val phone: String,
    val carModel: String,
    val plateNumber: String,
    val rating: Float,
    val totalRides: Int,
    val walletBalance: Double,
    val commissionDebt: Double,
    val maxDebtLimit: Double,
    val isOnline: Boolean
)

@Dao
interface AppDao {
    // Rides
    @Query("SELECT * FROM rides ORDER BY timestamp DESC")
    fun getAllRides(): Flow<List<RideEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRide(ride: RideEntity)

    @Update
    suspend fun updateRide(ride: RideEntity)

    // Commission Debts
    @Query("SELECT * FROM commission_debts ORDER BY id DESC")
    fun getAllCommissionDebts(): Flow<List<CommissionDebtEntity>>

    @Query("SELECT SUM(commissionAmount) FROM commission_debts WHERE isSettled = 0")
    fun getTotalUnsettledCommission(): Flow<Double?>

    @Query("SELECT SUM(commissionAmount) FROM commission_debts WHERE isSettled = 1")
    fun getTotalCollectedCommission(): Flow<Double?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCommissionDebt(debt: CommissionDebtEntity)

    @Query("UPDATE commission_debts SET isSettled = 1 WHERE captainId = :captainId")
    suspend fun settleCaptainDebts(captainId: String)

    // Wallet Transactions
    @Query("SELECT * FROM wallet_transactions ORDER BY id DESC")
    fun getAllWalletTransactions(): Flow<List<WalletTxEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWalletTransaction(tx: WalletTxEntity)

    // Captain Profile
    @Query("SELECT * FROM captain_profile WHERE id = :id LIMIT 1")
    suspend fun getCaptainProfile(id: String): CaptainProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveCaptainProfile(captain: CaptainProfileEntity)
}

@Database(
    entities = [
        RideEntity::class,
        CommissionDebtEntity::class,
        WalletTxEntity::class,
        CaptainProfileEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appDao(): AppDao
}
