package com.example.data.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.ElectricCar
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Money
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.ui.graphics.vector.ImageVector

enum class RideCategory(
    val id: String,
    val titleAr: String,
    val subtitleAr: String,
    val baseFare: Double,
    val perKmRate: Double,
    val seats: Int,
    val etaMinutes: Int
) {
    GO(
        id = "go",
        titleAr = "لحظتها جو (Go)",
        subtitleAr = "أسرع وأوفر رحلة يومية",
        baseFare = 15.0,
        perKmRate = 4.5,
        seats = 4,
        etaMinutes = 3
    ),
    SCOOTER(
        id = "scooter",
        titleAr = "لحظتها سكوتر (Scooter)",
        subtitleAr = "تخطي الزحام بسرعة فائقة وتكلفة اقتصادية",
        baseFare = 10.0,
        perKmRate = 2.8,
        seats = 1,
        etaMinutes = 2
    ),
    ECO(
        id = "eco",
        titleAr = "لحظتها إيكو (Eco)",
        subtitleAr = "سيارات اقتصادية حديثة وصديقة للبيئة",
        baseFare = 18.0,
        perKmRate = 4.0,
        seats = 4,
        etaMinutes = 4
    ),
    COMFORT(
        id = "comfort",
        titleAr = "لحظتها كومفورت (Comfort)",
        subtitleAr = "سيدان واسع، كباتن من النخبة وتكييف ممتاز",
        baseFare = 25.0,
        perKmRate = 6.0,
        seats = 4,
        etaMinutes = 5
    ),
    PLUS(
        id = "plus",
        titleAr = "لحظتها بلس عائلي (Plus 6)",
        subtitleAr = "سيارات عائلية ومجموعات حتى 6 أفراد",
        baseFare = 35.0,
        perKmRate = 8.0,
        seats = 6,
        etaMinutes = 7
    ),
    DELIVERY(
        id = "delivery",
        titleAr = "لحظتها توصيل فوري (Box)",
        subtitleAr = "توصيل طرود وأغراض بأمان وسرعة",
        baseFare = 12.0,
        perKmRate = 3.8,
        seats = 1,
        etaMinutes = 6
    )
}

data class VehicleCategory(
    val id: String,
    val titleAr: String,
    val subtitleAr: String,
    val vehicleType: String = "CAR", // CAR, SCOOTER, MOTORCYCLE, VAN, DELIVERY, TUKTUK
    val baseFare: Double,
    val perKmRate: Double,
    val seats: Int = 4,
    val etaMinutes: Int = 3,
    val isEnabled: Boolean = true
)

val DEFAULT_VEHICLE_CATEGORIES = listOf(
    VehicleCategory(
        id = "go",
        titleAr = "لحظتها جو (Go)",
        subtitleAr = "أسرع وأوفر رحلة يومية بالسيارة",
        vehicleType = "CAR",
        baseFare = 15.0,
        perKmRate = 4.5,
        seats = 4,
        etaMinutes = 3,
        isEnabled = true
    ),
    VehicleCategory(
        id = "scooter",
        titleAr = "لحظتها سكوتر (Scooter)",
        subtitleAr = "تخطي الزحام بسرعة فائقة وتكلفة اقتصادية",
        vehicleType = "SCOOTER",
        baseFare = 10.0,
        perKmRate = 2.8,
        seats = 1,
        etaMinutes = 2,
        isEnabled = true
    ),
    VehicleCategory(
        id = "eco",
        titleAr = "لحظتها إيكو (Eco)",
        subtitleAr = "سيارات اقتصادية حديثة وصديقة للبيئة",
        vehicleType = "CAR",
        baseFare = 18.0,
        perKmRate = 4.0,
        seats = 4,
        etaMinutes = 4,
        isEnabled = true
    ),
    VehicleCategory(
        id = "comfort",
        titleAr = "لحظتها كومفورت (Comfort)",
        subtitleAr = "سيدان واسع، كباتن من النخبة وتكييف ممتاز",
        vehicleType = "CAR",
        baseFare = 25.0,
        perKmRate = 6.0,
        seats = 4,
        etaMinutes = 5,
        isEnabled = true
    ),
    VehicleCategory(
        id = "plus",
        titleAr = "لحظتها بلس عائلي (Plus 6)",
        subtitleAr = "سيارات عائلية ومجموعات حتى 6 أفراد",
        vehicleType = "VAN",
        baseFare = 35.0,
        perKmRate = 8.0,
        seats = 6,
        etaMinutes = 7,
        isEnabled = true
    ),
    VehicleCategory(
        id = "delivery",
        titleAr = "لحظتها توصيل فوري (Box)",
        subtitleAr = "توصيل طرود وأغراض بأمان وسرعة",
        vehicleType = "DELIVERY",
        baseFare = 12.0,
        perKmRate = 3.8,
        seats = 1,
        etaMinutes = 6,
        isEnabled = true
    )
)

enum class PaymentType(val id: String, val titleAr: String, val icon: ImageVector) {
    WALLET("wallet", "محفظة لحظتها Pay", Icons.Default.AccountBalanceWallet),
    CARD("card", "بطاقة بنكية (Visa/Mastercard)", Icons.Default.CreditCard),
    CASH("cash", "دفع نقدي (كاش للكابتن)", Icons.Default.Money)
}

enum class RideStatus(val titleAr: String) {
    IDLE("جاهز للطلب"),
    SEARCHING("جارٍ البحث عن أقرب كابتن..."),
    REQUESTED("طلب جديد للكابتن"),
    CAPTAIN_ASSIGNED("تم قبول الرحلة - الكابتن في الطريق"),
    ARRIVED("وصل الكابتن إلى نقطة الالتقاء"),
    IN_PROGRESS("الرحلة جارية نحو الوجهة"),
    COMPLETED("تم الوصول بنجاح"),
    CANCELLED("تم إلغاء الرحلة")
}

data class CaptainInfo(
    val id: String,
    val name: String,
    val phone: String,
    val carModel: String,
    val carColor: String,
    val plateNumber: String,
    val rating: Float,
    val totalRides: Int,
    val acceptanceRate: Int,
    var walletBalance: Double = 350.0,
    var goldBalanceGrams: Double = 5.0, // رصيد سبائك وجرامات الذهب التحفيزية
    var commissionDebt: Double = 42.50, // App commission debt owed to the app platform
    var maxDebtLimit: Double = 100.0,  // Debt limit before blocking cash trips
    var isOnline: Boolean = true,
    var isDocumentsVerified: Boolean = true
)

enum class ApplicationStatus(val titleAr: String) {
    PENDING("قيد الفحص والمراجعة"),
    APPROVED("معتمد ومقبول"),
    REJECTED("مرفوض - أوراق غير واضحة")
}

data class DriverApplication(
    val id: String,
    val fullName: String,
    val nationalId: String,
    val phone: String,
    val vehicleType: String,
    val carModel: String,
    val plateNumber: String,
    val carColor: String,
    val licenseFrontUploaded: Boolean = true,
    val licenseBackUploaded: Boolean = true,
    val carLicenseUploaded: Boolean = true,
    val nationalIdUploaded: Boolean = true,
    val status: ApplicationStatus = ApplicationStatus.APPROVED,
    val submissionDate: String = "اليوم 10:30 ص",
    val rejectionReason: String? = null
)

data class GoldReward(
    val id: String,
    val captainId: String,
    val captainName: String,
    val goldGrams: Double,
    val equivalentEgp: Double,
    val reason: String,
    val date: String
)

data class RideItem(
    val id: String,
    val pickupAddress: String,
    val dropoffAddress: String,
    val pickupX: Float, // Normalized 0f..1f for custom map
    val pickupY: Float,
    val dropoffX: Float,
    val dropoffY: Float,
    val distanceKm: Double,
    val category: RideCategory,
    val totalFare: Double,
    val appCommissionRate: Double = 0.20, // 20% app commission (أرباح التطبيق)
    val appCommissionAmount: Double = totalFare * 0.20, // أرباح التطبيق المستقطعة من السائق
    val captainNetEarnings: Double = totalFare * 0.80, // صافي ربح الكابتن
    val paymentType: PaymentType,
    var status: RideStatus = RideStatus.IDLE,
    val captain: CaptainInfo? = null,
    val timestamp: Long = System.currentTimeMillis(),
    var userRating: Int = 0,
    var tipAmount: Double = 0.0
)

data class CommissionDebtItem(
    val id: String,
    val captainId: String,
    val captainName: String,
    val rideId: String,
    val totalFare: Double,
    val commissionAmount: Double,
    val paymentType: PaymentType,
    val date: String,
    val isSettled: Boolean
)

data class WalletTx(
    val id: String,
    val titleAr: String,
    val amount: Double,
    val isPositive: Boolean,
    val dateAr: String,
    val typeAr: String
)

data class SavedPlace(
    val id: String,
    val titleAr: String,
    val addressAr: String,
    val posX: Float,
    val posY: Float
)

data class ChatMessage(
    val id: String,
    val text: String,
    val isFromUser: Boolean,
    val time: String
)

data class CategoryPricing(
    val baseFare: Double,
    val perKmRate: Double
)

data class PromoOffer(
    val id: String,
    val code: String,
    val titleAr: String,
    val discountPercent: Int,
    val isActive: Boolean = true,
    val expiryNote: String = "ساري المفعول",
    val usageCount: Int = 0
)
